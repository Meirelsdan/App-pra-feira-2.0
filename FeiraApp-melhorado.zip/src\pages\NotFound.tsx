import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-6 pb-44 text-center">
      <span className="text-6xl">🥕</span>
      <h1 className="text-2xl font-extrabold">Página não encontrada</h1>
      <p className="text-base text-muted-foreground">Essa banca não existe por aqui.</p>
      <button
        onClick={() => navigate("/")}
        className="mt-2 h-14 rounded-2xl bg-primary px-8 text-lg font-bold text-primary-foreground"
      >
        Voltar ao início
      </button>
    </div>
  );
};

export default NotFound;
