import { createContext, useContext, useState, ReactNode } from "react";
import { Product, products } from "@/data/mockData";
import { usePersistentState } from "@/lib/storage";

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  getQuantity: (productId: string) => number;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
  /** controla a gaveta da Sacola Fixa */
  isBagOpen: boolean;
  setBagOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  // salvamos só id + quantidade; o produto vem sempre do catálogo atualizado
  const [stored, setStored] = usePersistentState<{ id: string; quantity: number }[]>("feiraapp:sacola", []);
  const [isBagOpen, setBagOpen] = useState(false);

  const items: CartItem[] = stored
    .map(({ id, quantity }) => {
      const product = products.find((p) => p.id === id);
      return product ? { product, quantity } : null;
    })
    .filter((i): i is CartItem => i !== null);

  const addItem = (product: Product) => {
    setStored((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        return prev.map((i) => (i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { id: product.id, quantity: 1 }];
    });
  };

  const removeItem = (productId: string) => {
    setStored((prev) => prev.filter((i) => i.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }
    setStored((prev) => prev.map((i) => (i.id === productId ? { ...i, quantity } : i)));
  };

  const getQuantity = (productId: string) => stored.find((i) => i.id === productId)?.quantity ?? 0;

  const clearCart = () => setStored([]);

  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        getQuantity,
        clearCart,
        totalItems,
        totalPrice,
        isBagOpen,
        setBagOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
};
