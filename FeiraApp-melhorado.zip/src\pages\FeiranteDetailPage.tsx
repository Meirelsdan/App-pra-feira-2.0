import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Star, Clock, MapPin, Truck } from "lucide-react";
import { categories, feirantes, formatPrice, products } from "@/data/mockData";
import ProductCard from "@/components/ProductCard";

export default function FeiranteDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const feirante = feirantes.find((f) => f.id === id);

  if (!feirante) return <div className="p-8 text-center text-lg text-muted-foreground">Feirante não encontrado</div>;

  const feiranteProducts = products.filter((p) => p.feiranteId === id);
  const sections = categories
    .map((c) => ({ category: c, items: feiranteProducts.filter((p) => p.category === c.id) }))
    .filter((s) => s.items.length > 0);

  return (
    <div className="min-h-screen pb-44">
      <div className="gradient-green rounded-b-[2rem] px-4 pb-6 pt-4">
        <button
          onClick={() => navigate(-1)}
          aria-label="Voltar"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-foreground/20"
        >
          <ArrowLeft size={22} className="text-primary-foreground" />
        </button>

        <div className="mt-4 flex items-center gap-4">
          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-3xl bg-primary-foreground/20 text-4xl">
            {feirante.avatar}
          </div>
          <div>
            <h1 className="text-xl font-extrabold leading-tight text-primary-foreground">{feirante.name}</h1>
            <p className="mt-1 text-sm text-primary-foreground/85">{feirante.description}</p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {[
            { icon: Star, label: `${feirante.rating.toString().replace(".", ",")} (${feirante.reviews} avaliações)`, fill: true },
            { icon: Clock, label: feirante.deliveryTime },
            { icon: MapPin, label: feirante.distance },
            { icon: Truck, label: `Entrega ${formatPrice(feirante.deliveryFee)}` },
          ].map((item, i) => (
            <div
              key={i}
              className="flex items-center gap-1.5 rounded-2xl bg-primary-foreground/15 px-3 py-2 text-sm font-semibold text-primary-foreground"
            >
              <item.icon size={16} fill={item.fill ? "currentColor" : "none"} className="shrink-0" />
              <span className="truncate">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="px-4 pt-5">
        {sections.map(({ category, items }) => (
          <section key={category.id} className="mb-6">
            <h2 className="flex items-center gap-2 text-lg font-extrabold">
              <span className="text-2xl">{category.emoji}</span> {category.name}
            </h2>
            <div className="mt-3 grid grid-cols-2 gap-3">
              {items.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        ))}
        {feiranteProducts.length === 0 && (
          <p className="mt-8 text-center text-base text-muted-foreground">Nenhum produto disponível no momento</p>
        )}
      </div>
    </div>
  );
}
