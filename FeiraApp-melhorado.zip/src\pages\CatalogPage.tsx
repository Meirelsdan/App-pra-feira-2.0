import { useMemo } from "react";
import { Search, X, Leaf, ArrowLeft } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import { categories, getCategory, products, Product } from "@/data/mockData";
import ProductCard from "@/components/ProductCard";

const normalize = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();

function ProductGrid({ items }: { items: Product[] }) {
  return (
    <div className="mt-3 grid grid-cols-2 gap-3">
      {items.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}

export default function CatalogPage() {
  const [params, setParams] = useSearchParams();
  const selectedCat = params.get("cat") || "";
  const query = params.get("q") || "";
  const onlyOrganic = params.get("organico") === "1";

  const update = (changes: Record<string, string>) => {
    const next = new URLSearchParams(params);
    Object.entries(changes).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    // trocar de categoria vira um novo passo no "voltar"; digitar na busca não
    setParams(next, { replace: !("cat" in changes) });
    if ("cat" in changes) window.scrollTo({ top: 0 });
  };

  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    return products.filter(
      (p) =>
        (!q || normalize(p.name).includes(q) || normalize(getCategory(p.category)?.name ?? "").includes(q)) &&
        (!selectedCat || p.category === selectedCat) &&
        (!onlyOrganic || p.organic),
    );
  }, [query, selectedCat, onlyOrganic]);

  const category = getCategory(selectedCat);
  const showOverview = !category && !query && !onlyOrganic;

  return (
    <div className="min-h-screen pb-44">
      {/* Cabeçalho fixo com busca e filtros */}
      <div className="sticky top-0 z-30 border-b border-border/70 bg-background/95 px-4 pb-3 pt-4 backdrop-blur-md">
        <div className="flex items-center gap-2">
          {category && (
            <button
              onClick={() => update({ cat: "" })}
              aria-label="Voltar ao catálogo"
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-card shadow-card ring-1 ring-border"
            >
              <ArrowLeft size={22} />
            </button>
          )}
          <h1 className="text-xl font-extrabold text-foreground">{category ? category.name : "Catálogo"}</h1>
        </div>

        <div className="mt-3 flex items-center gap-2 rounded-2xl bg-card px-4 shadow-card ring-1 ring-border focus-within:ring-4 focus-within:ring-ring/30">
          <Search size={20} className="shrink-0 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => update({ q: e.target.value })}
            placeholder={category ? `Buscar em ${category.name.toLowerCase()}...` : "Buscar: banana, queijo, pastel..."}
            aria-label="Buscar produtos"
            className="h-12 flex-1 bg-transparent text-base font-medium text-foreground outline-none placeholder:text-muted-foreground"
          />
          {query && (
            <button onClick={() => update({ q: "" })} aria-label="Limpar busca" className="p-1">
              <X size={20} className="text-muted-foreground" />
            </button>
          )}
        </div>

        <div className="-mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-1 scrollbar-none">
          <button
            onClick={() => update({ organico: onlyOrganic ? "" : "1" })}
            aria-pressed={onlyOrganic}
            className={`flex h-10 shrink-0 items-center gap-1 rounded-full px-4 text-sm font-bold transition ${
              onlyOrganic ? "bg-primary text-primary-foreground" : "bg-accent text-accent-foreground"
            }`}
          >
            <Leaf size={14} /> Só orgânicos
          </button>
          <span className="w-px shrink-0 bg-border" />
          <button
            onClick={() => update({ cat: "" })}
            className={`h-10 shrink-0 rounded-full px-4 text-sm font-bold transition ${
              !selectedCat ? "bg-foreground text-background" : "bg-muted text-muted-foreground"
            }`}
          >
            Tudo
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => update({ cat: selectedCat === c.id ? "" : c.id })}
              className={`h-10 shrink-0 rounded-full px-4 text-sm font-bold transition ${
                selectedCat === c.id ? "bg-foreground text-background" : "bg-muted text-muted-foreground"
              }`}
            >
              {c.emoji} {c.name}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pt-4">
        {/* Visão geral: blocos grandes por categoria */}
        {showOverview && (
          <div className="grid grid-cols-2 gap-3">
            {categories.map((c) => {
              const count = products.filter((p) => p.category === c.id).length;
              return (
                <button
                  key={c.id}
                  onClick={() => update({ cat: c.id })}
                  className="flex flex-col items-start rounded-3xl p-4 text-left shadow-card ring-1 ring-black/5 transition active:scale-[0.98]"
                  style={{ backgroundColor: `hsl(${c.tint})` }}
                >
                  <span className="text-4xl">{c.emoji}</span>
                  <span className="mt-2 text-base font-extrabold leading-tight text-foreground">{c.name}</span>
                  <span className="mt-0.5 text-sm font-semibold text-foreground/70">{count} produtos</span>
                  <span className="mt-2 line-clamp-2 text-xs text-foreground/60">
                    {c.groups.map((g) => g.name).join(" · ")}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Categoria escolhida: separada por tipo */}
        {category && (
          <>
            {category.groups.length > 1 && (
              <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 scrollbar-none">
                {category.groups.map((g) => {
                  const n = filtered.filter((p) => p.group === g.id).length;
                  if (n === 0) return null;
                  return (
                    <a
                      key={g.id}
                      href={`#tipo-${g.id}`}
                      onClick={(e) => {
                        e.preventDefault();
                        document.getElementById(`tipo-${g.id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
                      }}
                      className="flex h-10 shrink-0 items-center rounded-full bg-card px-4 text-sm font-bold text-foreground shadow-sm ring-1 ring-border"
                    >
                      {g.name} <span className="ml-1.5 text-muted-foreground">{n}</span>
                    </a>
                  );
                })}
              </div>
            )}

            {category.groups.map((g) => {
              const items = filtered.filter((p) => p.group === g.id);
              if (items.length === 0) return null;
              return (
                <section key={g.id} id={`tipo-${g.id}`} className="scroll-mt-48 pt-4">
                  <div
                    className="flex items-center gap-2 rounded-2xl px-4 py-2.5"
                    style={{ backgroundColor: `hsl(${category.tint})` }}
                  >
                    <span className="text-xl">{category.emoji}</span>
                    <h2 className="flex-1 text-lg font-extrabold text-foreground">{g.name}</h2>
                    <span className="text-sm font-bold text-foreground/60">{items.length}</span>
                  </div>
                  <ProductGrid items={items} />
                </section>
              );
            })}
          </>
        )}

        {/* Busca ou filtro de orgânicos sem categoria: resultados agrupados por categoria */}
        {!category && !showOverview && (
          <>
            <p className="text-sm font-semibold text-muted-foreground">
              {filtered.length} {filtered.length === 1 ? "produto encontrado" : "produtos encontrados"}
            </p>
            {categories.map((c) => {
              const items = filtered.filter((p) => p.category === c.id);
              if (items.length === 0) return null;
              return (
                <section key={c.id} className="pt-5">
                  <h2 className="flex items-center gap-2 text-lg font-extrabold">
                    <span className="text-2xl">{c.emoji}</span> {c.name}
                  </h2>
                  <ProductGrid items={items} />
                </section>
              );
            })}
          </>
        )}

        {!showOverview && filtered.length === 0 && (
          <div className="mt-12 text-center">
            <p className="text-5xl">🔍</p>
            <p className="mt-3 text-base font-bold text-muted-foreground">Nenhum produto encontrado</p>
            <button
              onClick={() => setParams({})}
              className="mt-4 h-12 rounded-2xl bg-primary px-6 text-base font-bold text-primary-foreground"
            >
              Ver catálogo completo
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
