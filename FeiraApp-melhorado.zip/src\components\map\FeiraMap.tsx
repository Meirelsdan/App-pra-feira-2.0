import { ReactNode, useEffect } from "react";
import { APIProvider, AdvancedMarker, Map, Pin, useMap } from "@vis.gl/react-google-maps";
import type { MapMouseEvent } from "@vis.gl/react-google-maps";
import { MapPinOff } from "lucide-react";
import type { Feira } from "@/data/mockData";
import type { LatLng } from "@/contexts/FeirasContext";

/**
 * Google Maps
 * Configure no arquivo .env (veja .env.example):
 *   VITE_GOOGLE_MAPS_API_KEY=sua-chave
 *   VITE_GOOGLE_MAPS_MAP_ID=seu-map-id   (opcional; sem ele usamos o DEMO_MAP_ID)
 * APIs que precisam estar ativas no Google Cloud: Maps JavaScript API e Geocoding API.
 */
const MAPS_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
const MAP_ID = (import.meta.env.VITE_GOOGLE_MAPS_MAP_ID as string | undefined) || "DEMO_MAP_ID";

export const hasMapsKey = Boolean(MAPS_KEY);
export const SAO_PAULO: LatLng = { lat: -23.5505, lng: -46.6633 };

const COLORS = {
  oficial: "#2f8a4f",
  comunidade: "#e47d2e",
  draft: "#d6336c",
};

export function MapsProvider({ children }: { children: ReactNode }) {
  if (!MAPS_KEY) return <>{children}</>;
  return (
    <APIProvider apiKey={MAPS_KEY} language="pt-BR" region="BR">
      {children}
    </APIProvider>
  );
}

/** Link "Como chegar" do Google Maps — funciona mesmo sem chave de API. */
export function directionsUrl(feira: Pick<Feira, "lat" | "lng" | "address" | "name">) {
  const destination =
    feira.lat != null && feira.lng != null ? `${feira.lat},${feira.lng}` : `${feira.name}, ${feira.address}`;
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`;
}

/** Geocoder do Google (endereço ⇄ coordenadas), carregado sob demanda. */
async function getGeocoder() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const g = (window as any).google;
  if (!g?.maps?.importLibrary) return null;
  const { Geocoder } = await g.maps.importLibrary("geocoding");
  return new Geocoder();
}

export async function addressFromLatLng(pos: LatLng): Promise<string | null> {
  try {
    const geocoder = await getGeocoder();
    if (!geocoder) return null;
    const { results } = await geocoder.geocode({ location: pos });
    return results?.[0]?.formatted_address ?? null;
  } catch {
    return null;
  }
}

export async function latLngFromAddress(address: string): Promise<LatLng | null> {
  try {
    const geocoder = await getGeocoder();
    if (!geocoder) return null;
    const { results } = await geocoder.geocode({ address, region: "BR" });
    const loc = results?.[0]?.geometry?.location;
    return loc ? { lat: loc.lat(), lng: loc.lng() } : null;
  } catch {
    return null;
  }
}

function PanTo({ target, zoom }: { target: LatLng | null | undefined; zoom?: number }) {
  const map = useMap();
  useEffect(() => {
    if (!map || !target) return;
    map.panTo(target);
    if (zoom) map.setZoom(zoom);
  }, [map, target, zoom]);
  return null;
}

interface FeiraMapProps {
  feiras: Feira[];
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  userLocation?: LatLng | null;
  /** ponto que o usuário está marcando para cadastrar uma feira nova */
  draft?: LatLng | null;
  pickMode?: boolean;
  onPick?: (pos: LatLng) => void;
  center?: LatLng;
  zoom?: number;
  /** quando muda, o mapa se move até esse ponto */
  focus?: LatLng | null;
  className?: string;
}

export default function FeiraMap({
  feiras,
  selectedId,
  onSelect,
  userLocation,
  draft,
  pickMode,
  onPick,
  center,
  zoom = 13,
  focus,
  className = "",
}: FeiraMapProps) {
  if (!hasMapsKey) return <MapFallback className={className} />;

  const handleClick = (e: MapMouseEvent) => {
    const pos = e.detail.latLng;
    if (pickMode && pos) onPick?.(pos);
    else onSelect?.(null);
  };

  return (
    <div className={`relative overflow-hidden ${pickMode ? "cursor-crosshair" : ""} ${className}`}>
      <Map
        defaultCenter={center ?? SAO_PAULO}
        defaultZoom={zoom}
        mapId={MAP_ID}
        gestureHandling="greedy"
        disableDefaultUI
        zoomControl
        clickableIcons={false}
        onClick={handleClick}
        style={{ width: "100%", height: "100%" }}
      >
        {feiras
          .filter((f) => f.lat != null && f.lng != null)
          .map((f) => {
            const selected = f.id === selectedId;
            return (
              <AdvancedMarker
                key={f.id}
                position={{ lat: f.lat!, lng: f.lng! }}
                title={f.name}
                zIndex={selected ? 10 : 1}
                onClick={() => onSelect?.(f.id)}
              >
                <Pin
                  background={COLORS[f.source]}
                  borderColor="#ffffff"
                  glyphColor="#ffffff"
                  scale={selected ? 1.45 : 1.15}
                />
              </AdvancedMarker>
            );
          })}

        {userLocation && (
          <AdvancedMarker position={userLocation} title="Você está aqui" zIndex={20}>
            <span className="block h-5 w-5 rounded-full border-[3px] border-white bg-blue-600 shadow-lg ring-8 ring-blue-500/25" />
          </AdvancedMarker>
        )}

        {draft && (
          <AdvancedMarker position={draft} title="Nova feira" zIndex={30}>
            <Pin background={COLORS.draft} borderColor="#ffffff" glyphColor="#ffffff" scale={1.5} />
          </AdvancedMarker>
        )}

        <PanTo target={focus} zoom={focus ? 15 : undefined} />
      </Map>
    </div>
  );
}

function MapFallback({ className }: { className: string }) {
  return (
    <div
      className={`flex flex-col items-center justify-center gap-2 bg-feira-green-light p-6 text-center ${className}`}
    >
      <MapPinOff size={36} className="text-primary" />
      <p className="text-base font-extrabold text-foreground">Mapa indisponível</p>
      <p className="max-w-xs text-sm text-muted-foreground">
        Para ativar o Google Maps, coloque sua chave em <code className="font-bold">VITE_GOOGLE_MAPS_API_KEY</code> no
        arquivo <code className="font-bold">.env</code>. Enquanto isso, as feiras aparecem na lista abaixo.
      </p>
    </div>
  );
}

export function MapLegend() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm font-semibold text-muted-foreground">
      <span className="flex items-center gap-1.5">
        <span className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS.oficial }} /> Feira oficial
      </span>
      <span className="flex items-center gap-1.5">
        <span className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS.comunidade }} /> Marcada por
        clientes/feirantes
      </span>
    </div>
  );
}
