import { useNavigate } from "react-router-dom";
import { User, MapPin, Heart, Settings, HelpCircle, LogOut, ChevronRight, Bell, Wallet, MapPinned } from "lucide-react";
import { PageHeader } from "@/components/common";
import { describeMethod, paymentTypeInfo, useWallet } from "@/contexts/WalletContext";
import { useFeiras } from "@/contexts/FeirasContext";

const menuItems = [
  { icon: MapPin, label: "Meus endereços" },
  { icon: Heart, label: "Favoritos" },
  { icon: Bell, label: "Notificações" },
  { icon: Settings, label: "Configurações" },
  { icon: HelpCircle, label: "Ajuda" },
];

export default function ProfilePage() {
  const navigate = useNavigate();
  const { methods, defaultMethod } = useWallet();
  const { role, setRole, feiras } = useFeiras();
  const myFeiras = feiras.filter((f) => f.source === "comunidade");

  return (
    <div className="min-h-screen pb-44">
      <PageHeader title="Perfil" />

      <div className="flex flex-col gap-4 px-4 pt-4">
        <div className="flex items-center gap-4 rounded-3xl bg-card p-4 shadow-card ring-1 ring-border/60">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-accent">
            <User size={32} className="text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-foreground">Visitante</h2>
            <p className="text-sm text-muted-foreground">Faça login para aproveitar todos os recursos</p>
          </div>
        </div>

        {/* Tipo de perfil */}
        <div className="rounded-3xl bg-card p-4 shadow-card ring-1 ring-border/60">
          <p className="mb-2 text-sm font-extrabold">Eu sou</p>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                ["cliente", "🛒", "Cliente"],
                ["feirante", "🧑‍🌾", "Feirante"],
              ] as const
            ).map(([value, emoji, label]) => (
              <button
                key={value}
                onClick={() => setRole(value)}
                aria-pressed={role === value}
                className={`flex h-14 items-center justify-center gap-2 rounded-2xl text-base font-bold transition ${
                  role === value ? "bg-primary text-primary-foreground shadow-md" : "bg-muted text-muted-foreground"
                }`}
              >
                <span className="text-xl">{emoji}</span> {label}
              </button>
            ))}
          </div>
        </div>

        {/* Carteira */}
        <button
          onClick={() => navigate("/perfil/carteira")}
          className="gradient-green relative overflow-hidden rounded-3xl p-4 text-left text-primary-foreground shadow-card-hover transition active:scale-[0.99]"
        >
          <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
          <div className="relative flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20">
              <Wallet size={26} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-lg font-extrabold">Carteira</p>
              <p className="truncate text-sm opacity-90">
                {defaultMethod
                  ? `${paymentTypeInfo[defaultMethod.type].emoji} ${defaultMethod.nickname} · ${describeMethod(defaultMethod)}`
                  : "Adicione Pix, cartão, vale ou dinheiro"}
              </p>
            </div>
            <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-sm font-bold">{methods.length}</span>
            <ChevronRight size={22} />
          </div>
        </button>

        {/* Pontos de feira marcados */}
        <button
          onClick={() => navigate("/feiras")}
          className="flex items-center gap-3 rounded-3xl bg-card p-4 text-left shadow-card ring-1 ring-border/60"
        >
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-feira-orange-light">
            <MapPinned size={24} className="text-secondary" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-base font-extrabold">
              {role === "feirante" ? "Onde eu vendo" : "Pontos de feira marcados"}
            </p>
            <p className="text-sm text-muted-foreground">
              {myFeiras.length > 0
                ? `${myFeiras.length} ${myFeiras.length === 1 ? "ponto marcado" : "pontos marcados"} no mapa`
                : "Marque no mapa uma feira que você conhece"}
            </p>
          </div>
          <ChevronRight size={20} className="text-muted-foreground" />
        </button>

        <div className="overflow-hidden rounded-3xl bg-card shadow-card ring-1 ring-border/60">
          {menuItems.map((item, i) => (
            <button
              key={item.label}
              className={`flex w-full items-center justify-between px-4 py-4 text-left transition-colors hover:bg-muted/50 ${
                i < menuItems.length - 1 ? "border-b border-border" : ""
              }`}
            >
              <div className="flex items-center gap-3">
                <item.icon size={20} className="text-primary" />
                <span className="text-base font-semibold text-foreground">{item.label}</span>
              </div>
              <ChevronRight size={18} className="text-muted-foreground" />
            </button>
          ))}
        </div>

        <button className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl border border-destructive/30 text-base font-bold text-destructive transition-colors hover:bg-destructive/5">
          <LogOut size={18} />
          Sair
        </button>
      </div>
    </div>
  );
}
