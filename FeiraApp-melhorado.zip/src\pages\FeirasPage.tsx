import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { LocateFixed, Plus, X, Navigation, ChevronRight, Calendar, Clock } from "lucide-react";
import { toast } from "sonner";
import FeiraCard from "@/components/FeiraCard";
import { PageHeader, SectionTitle } from "@/components/common";
import FeiraMap, { MapLegend, directionsUrl, hasMapsKey } from "@/components/map/FeiraMap";
import AddFeiraSheet from "@/components/map/AddFeiraSheet";
import { LatLng, useFeiras } from "@/contexts/FeirasContext";

export default function FeirasPage() {
  const { feiras, userLocation, requestLocation } = useFeiras();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [focus, setFocus] = useState<LatLng | null>(null);
  const [pickMode, setPickMode] = useState(false);
  const [draft, setDraft] = useState<LatLng | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const selected = feiras.find((f) => f.id === selectedId);

  const startAdding = () => {
    if (hasMapsKey) {
      setPickMode(true);
      setSelectedId(null);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setFormOpen(true);
    }
  };

  // atalho vindo da tela inicial: /feiras?adicionar=1
  useEffect(() => {
    if (params.get("adicionar")) {
      startAdding();
      setParams({}, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectFeira = (id: string | null) => {
    setSelectedId(id);
    const f = feiras.find((x) => x.id === id);
    if (f?.lat != null && f.lng != null) setFocus({ lat: f.lat, lng: f.lng });
  };

  const goToMyLocation = async () => {
    const loc = await requestLocation();
    if (loc) setFocus({ ...loc });
    else toast.error("Não foi possível pegar sua localização. Verifique a permissão do navegador.");
  };

  return (
    <div className="min-h-screen pb-44">
      <PageHeader title="Mapa de Feiras" subtitle="Encontre feiras perto de você ou marque uma nova" />

      <div className="px-4 pt-4">
        <div className="relative">
          <FeiraMap
            feiras={feiras}
            selectedId={selectedId}
            onSelect={selectFeira}
            userLocation={userLocation}
            draft={draft}
            pickMode={pickMode}
            onPick={(pos) => {
              setDraft(pos);
              setPickMode(false);
              setFormOpen(true);
            }}
            focus={focus}
            className="h-[48vh] min-h-[300px] rounded-3xl shadow-card ring-1 ring-border"
          />

          {hasMapsKey && !pickMode && (
            <button
              onClick={goToMyLocation}
              className="absolute left-3 top-3 flex h-11 items-center gap-1.5 rounded-full bg-card px-4 text-sm font-bold text-foreground shadow-lg ring-1 ring-border"
            >
              <LocateFixed size={18} className="text-primary" /> Perto de mim
            </button>
          )}

          {pickMode && (
            <div className="absolute inset-x-3 top-3 flex items-center gap-2 rounded-2xl bg-foreground/90 p-3 text-background shadow-lg">
              <span className="text-2xl">👆</span>
              <p className="flex-1 text-base font-bold leading-snug">Toque no mapa onde acontece a feira</p>
              <button
                onClick={() => setPickMode(false)}
                aria-label="Cancelar"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-background/20"
              >
                <X size={20} />
              </button>
            </div>
          )}
        </div>

        <div className="mt-3">
          <MapLegend />
        </div>

        {selected && (
          <div className="mt-4 rounded-3xl bg-card p-4 shadow-card ring-2 ring-primary/40">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h2 className="text-lg font-extrabold leading-tight">{selected.name}</h2>
                <p className="mt-0.5 text-sm text-muted-foreground">{selected.address}</p>
              </div>
              <button
                onClick={() => setSelectedId(null)}
                aria-label="Fechar"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted"
              >
                <X size={18} />
              </button>
            </div>
            <div className="mt-2 flex flex-wrap gap-x-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar size={15} className="text-secondary" /> {selected.days}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={15} className="text-secondary" /> {selected.hours}
              </span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a
                href={directionsUrl(selected)}
                target="_blank"
                rel="noreferrer"
                className="flex h-12 items-center justify-center gap-1.5 rounded-2xl bg-muted text-sm font-extrabold text-foreground"
              >
                <Navigation size={18} /> Como chegar
              </a>
              <button
                onClick={() => navigate(`/feira/${selected.id}`)}
                className="flex h-12 items-center justify-center gap-1 rounded-2xl bg-primary text-sm font-extrabold text-primary-foreground"
              >
                Ver feira <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}

        <button
          onClick={startAdding}
          disabled={pickMode}
          className="gradient-orange mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-2xl text-base font-extrabold text-secondary-foreground shadow-md transition active:scale-[0.98] disabled:opacity-50"
        >
          <Plus size={22} strokeWidth={3} /> Marcar nova feira no mapa
        </button>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Clientes e feirantes podem adicionar pontos de feira.
        </p>

        <div className="mt-6">
          <SectionTitle>{userLocation ? "Mais perto de você" : "Todas as feiras"}</SectionTitle>
        </div>
        <div className="mt-3 flex flex-col gap-3">
          {feiras.map((f) => (
            <FeiraCard key={f.id} feira={f} />
          ))}
        </div>
      </div>

      <AddFeiraSheet
        open={formOpen}
        onOpenChange={(open) => {
          setFormOpen(open);
          if (!open && !pickMode) setDraft(null);
        }}
        position={draft}
        onPositionChange={(pos) => {
          setDraft(pos);
          if (pos) setFocus({ ...pos });
        }}
        onPickOnMap={() => {
          setFormOpen(false);
          setPickMode(true);
        }}
        onSaved={(feira) => {
          setFormOpen(false);
          setDraft(null);
          setSelectedId(feira.id);
          if (feira.lat != null && feira.lng != null) setFocus({ lat: feira.lat, lng: feira.lng });
        }}
      />
    </div>
  );
}
