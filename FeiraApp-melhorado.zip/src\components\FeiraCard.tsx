import { MapPin, Calendar, Clock, Users } from "lucide-react";
import { Feira } from "@/data/mockData";
import { useNavigate } from "react-router-dom";

export default function FeiraCard({ feira, onClick }: { feira: Feira; onClick?: () => void }) {
  const navigate = useNavigate();

  return (
    <button
      onClick={onClick ?? (() => navigate(`/feira/${feira.id}`))}
      className="w-full overflow-hidden rounded-3xl bg-card text-left shadow-card ring-1 ring-border/60 transition-shadow hover:shadow-card-hover"
    >
      <div className="relative h-32 overflow-hidden">
        <img src={feira.image} alt="" className="h-full w-full object-cover" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/75 via-foreground/20 to-transparent" />
        <h3 className="absolute bottom-2 left-3 right-3 text-base font-extrabold leading-tight text-primary-foreground drop-shadow">
          {feira.name}
        </h3>
        <div className="absolute left-2 right-2 top-2 flex items-center justify-between gap-2">
          {feira.source === "comunidade" ? (
            <span className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-0.5 text-xs font-bold text-secondary-foreground">
              <Users size={12} /> {feira.addedBy === "feirante" ? "Marcada por feirante" : "Marcada por cliente"}
            </span>
          ) : (
            <span />
          )}
          {feira.distance && (
            <span className="rounded-full bg-card/95 px-2.5 py-0.5 text-xs font-bold text-foreground backdrop-blur-sm">
              {feira.distance}
            </span>
          )}
        </div>
      </div>
      <div className="flex flex-col gap-1.5 p-3">
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <MapPin size={15} className="shrink-0 text-primary" />
          <span className="truncate">{feira.address}</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Calendar size={15} className="text-secondary" /> {feira.days}
          </span>
          <span className="flex items-center gap-1">
            <Clock size={15} className="text-secondary" /> {feira.hours}
          </span>
        </div>
      </div>
    </button>
  );
}
