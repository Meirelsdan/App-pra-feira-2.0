import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Pencil, Plus, Wallet, CheckCircle2, MapPin } from "lucide-react";
import { toast } from "sonner";
import { useCart } from "@/contexts/CartContext";
import { describeMethod, paymentTypeInfo, useWallet } from "@/contexts/WalletContext";
import { formatPrice } from "@/data/mockData";
import { PageHeader, ProductThumb, QuantityStepper } from "@/components/common";
import { groupByFeirante } from "@/components/SacolaFixa";
import { usePersistentState } from "@/lib/storage";

export default function CheckoutPage() {
  const { items, updateQuantity, totalPrice, clearCart } = useCart();
  const { methods, defaultMethod } = useWallet();
  const navigate = useNavigate();
  const [paymentId, setPaymentId] = useState<string | undefined>(defaultMethod?.id);
  const [address, setAddress] = usePersistentState("feiraapp:endereco-entrega", "");
  const [orderNumber, setOrderNumber] = useState<number | null>(null);

  const groups = groupByFeirante(items);
  const deliveryFees = groups.reduce((sum, g) => sum + g.feirante.deliveryFee, 0);
  const total = totalPrice + deliveryFees;
  const payment = methods.find((m) => m.id === paymentId) ?? defaultMethod;

  if (orderNumber) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-6 pb-28 text-center">
        <CheckCircle2 size={72} className="text-primary" />
        <h1 className="text-2xl font-extrabold">Pedido feito! 🎉</h1>
        <p className="text-base text-muted-foreground">
          Pedido nº <b>{orderNumber}</b>. Os feirantes já foram avisados e vão separar tudo fresquinho pra você.
        </p>
        <button
          onClick={() => navigate("/")}
          className="mt-3 h-14 w-full max-w-xs rounded-2xl bg-primary text-lg font-extrabold text-primary-foreground"
        >
          Voltar ao início
        </button>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen">
        <PageHeader title="Fechar pedido" back />
        <div className="flex flex-col items-center gap-3 px-6 pt-20 text-center">
          <span className="text-6xl">🧺</span>
          <h2 className="text-xl font-extrabold">Sua Sacola Fixa está vazia</h2>
          <p className="text-base text-muted-foreground">Adicione produtos do catálogo para fazer o pedido.</p>
          <button
            onClick={() => navigate("/catalogo")}
            className="mt-2 h-14 rounded-2xl bg-primary px-8 text-lg font-bold text-primary-foreground"
          >
            Ver catálogo
          </button>
        </div>
      </div>
    );
  }

  const confirm = () => {
    if (!address.trim()) return toast.error("Informe o endereço de entrega");
    if (!payment) return toast.error("Escolha uma forma de pagamento");
    setOrderNumber(Math.floor(10000 + Math.random() * 90000));
    clearCart();
  };

  return (
    <div className="min-h-screen pb-56">
      <PageHeader title="Fechar pedido" subtitle="Confira sua Sacola Fixa" back />

      <div className="flex flex-col gap-6 px-4 pt-4">
        {/* Itens */}
        {groups.map(({ feirante, items: groupItems }) => (
          <section key={feirante.id} className="rounded-3xl bg-card p-4 shadow-card ring-1 ring-border/60">
            <h2 className="flex items-center gap-2 text-base font-extrabold">
              <span className="text-2xl">{feirante.avatar}</span>
              <span className="min-w-0 flex-1 truncate">{feirante.name}</span>
            </h2>
            <p className="mb-3 text-sm text-muted-foreground">
              Entrega {feirante.deliveryTime} · {formatPrice(feirante.deliveryFee)}
            </p>
            <div className="flex flex-col divide-y divide-border">
              {groupItems.map(({ product, quantity }) => (
                <div key={product.id} className="flex items-center gap-3 py-2.5">
                  <ProductThumb product={product} className="h-12 w-12 text-2xl" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-base font-bold">{product.name}</p>
                    <p className="text-sm font-extrabold text-primary">{formatPrice(product.price * quantity)}</p>
                  </div>
                  <div className="w-[8.5rem] shrink-0">
                    <QuantityStepper size="sm" value={quantity} onChange={(q) => updateQuantity(product.id, q)} />
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}

        {/* Endereço */}
        <section>
          <h2 className="mb-2 flex items-center gap-2 text-lg font-extrabold">
            <MapPin size={20} className="text-primary" /> Endereço de entrega
          </h2>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            rows={2}
            placeholder="Rua, número, apartamento, bairro"
            className="w-full resize-none rounded-2xl border border-input bg-card p-4 text-base outline-none focus:ring-4 focus:ring-ring/30"
          />
        </section>

        {/* Pagamento */}
        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-extrabold">
              <Wallet size={20} className="text-primary" /> Pagamento
            </h2>
            <button
              onClick={() => navigate("/perfil/carteira?voltar=/sacola")}
              className="flex items-center gap-1 text-sm font-bold text-primary"
            >
              <Pencil size={14} /> Carteira
            </button>
          </div>

          {methods.length === 0 ? (
            <button
              onClick={() => navigate("/perfil/carteira?voltar=/sacola&novo=1")}
              className="flex w-full items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-primary/40 bg-accent/50 p-5 text-base font-bold text-primary"
            >
              <Plus size={20} /> Adicionar forma de pagamento
            </button>
          ) : (
            <div role="radiogroup" className="flex flex-col gap-2">
              {methods.map((m) => {
                const active = payment?.id === m.id;
                return (
                  <button
                    key={m.id}
                    role="radio"
                    aria-checked={active}
                    onClick={() => setPaymentId(m.id)}
                    className={`flex items-center gap-3 rounded-2xl bg-card p-3 text-left ring-2 transition ${
                      active ? "ring-primary" : "ring-border"
                    }`}
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-accent text-2xl">
                      {paymentTypeInfo[m.type].emoji}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-base font-bold">{m.nickname}</span>
                      <span className="block truncate text-sm text-muted-foreground">{describeMethod(m)}</span>
                    </span>
                    <span
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${
                        active ? "border-primary bg-primary" : "border-muted-foreground/40"
                      }`}
                    >
                      {active && <span className="h-2.5 w-2.5 rounded-full bg-primary-foreground" />}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Resumo fixo */}
      <div className="fixed inset-x-0 bottom-[calc(4.4rem_+_env(safe-area-inset-bottom))] z-40 border-t border-border bg-card/95 backdrop-blur-md">
        <div className="mx-auto max-w-lg px-4 py-3">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Produtos</span>
            <span>{formatPrice(totalPrice)}</span>
          </div>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Entrega ({groups.length} {groups.length === 1 ? "feirante" : "feirantes"})</span>
            <span>{formatPrice(deliveryFees)}</span>
          </div>
          <div className="mt-2 flex items-center justify-between gap-3">
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-2xl font-black">{formatPrice(total)}</p>
            </div>
            <button
              onClick={confirm}
              className="gradient-green h-14 flex-1 rounded-2xl text-lg font-extrabold text-primary-foreground shadow-md transition active:scale-[0.98]"
            >
              Confirmar pedido
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
