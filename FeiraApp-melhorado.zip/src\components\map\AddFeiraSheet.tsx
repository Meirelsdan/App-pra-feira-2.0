import { useEffect, useState } from "react";
import { Crosshair, LocateFixed, MapPin, Search, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Feira } from "@/data/mockData";
import { LatLng, UserRole, useFeiras } from "@/contexts/FeirasContext";
import { addressFromLatLng, hasMapsKey, latLngFromAddress } from "@/components/map/FeiraMap";

const DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];

function joinDays(days: string[]) {
  const ordered = DAYS.filter((d) => days.includes(d));
  if (ordered.length <= 1) return ordered.join("");
  return `${ordered.slice(0, -1).join(", ")} e ${ordered[ordered.length - 1]}`;
}

function formatHour(t: string) {
  const [h, m] = t.split(":").map(Number);
  return m ? `${h}h${String(m).padStart(2, "0")}` : `${h}h`;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  position: LatLng | null;
  onPositionChange: (pos: LatLng | null) => void;
  /** fecha o formulário e volta ao mapa para escolher o local tocando nele */
  onPickOnMap: () => void;
  onSaved: (feira: Feira) => void;
}

const inputClass =
  "h-12 w-full rounded-2xl border border-input bg-card px-4 text-base font-medium text-foreground outline-none ring-ring/40 placeholder:text-muted-foreground focus:ring-4";

export default function AddFeiraSheet({ open, onOpenChange, position, onPositionChange, onPickOnMap, onSaved }: Props) {
  const { addFeira, role, requestLocation } = useFeiras();

  // estado fica fora do SheetContent para não se perder ao voltar ao mapa
  const [addedBy, setAddedBy] = useState<UserRole>(role);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [bancaName, setBancaName] = useState("");
  const [days, setDays] = useState<string[]>([]);
  const [start, setStart] = useState("06:00");
  const [end, setEnd] = useState("12:00");
  const [busy, setBusy] = useState<"geo" | "locate" | null>(null);

  useEffect(() => setAddedBy(role), [role]);

  // quando um ponto é marcado no mapa, tenta descobrir o endereço
  useEffect(() => {
    if (!position) return;
    let cancelled = false;
    setBusy("geo");
    addressFromLatLng(position).then((addr) => {
      if (cancelled) return;
      if (addr) setAddress(addr);
      setBusy(null);
    });
    return () => {
      cancelled = true;
    };
  }, [position]);

  const reset = () => {
    setName("");
    setAddress("");
    setBancaName("");
    setDays([]);
    setStart("06:00");
    setEnd("12:00");
  };

  const findAddress = async () => {
    if (!address.trim()) return toast.error("Digite o endereço primeiro");
    setBusy("locate");
    const pos = await latLngFromAddress(address);
    setBusy(null);
    if (pos) {
      onPositionChange(pos);
      toast.success("Endereço encontrado no mapa!");
    } else {
      toast.error("Não encontramos esse endereço. Tente marcar tocando no mapa.");
    }
  };

  const useMyLocation = async () => {
    setBusy("locate");
    const pos = await requestLocation();
    setBusy(null);
    if (pos) onPositionChange(pos);
    else toast.error("Não foi possível pegar sua localização. Verifique a permissão do navegador.");
  };

  const save = () => {
    if (!name.trim()) return toast.error("Dê um nome para a feira");
    if (!address.trim()) return toast.error("Informe o endereço da feira");
    if (days.length === 0) return toast.error("Escolha pelo menos um dia da semana");
    if (hasMapsKey && !position) return toast.error("Marque o local da feira no mapa");

    const feira = addFeira({
      name: name.trim(),
      address: address.trim(),
      days: joinDays(days),
      hours: `${formatHour(start)} às ${formatHour(end)}`,
      lat: position?.lat,
      lng: position?.lng,
      addedBy,
      bancaName: addedBy === "feirante" && bancaName.trim() ? bancaName.trim() : undefined,
    });
    toast.success("Ponto de feira adicionado! Obrigado por ajudar 💚");
    reset();
    onSaved(feira);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="mx-auto max-h-[92vh] max-w-lg overflow-y-auto rounded-t-3xl pb-8">
        <SheetHeader className="text-left">
          <SheetTitle className="text-2xl font-extrabold">Marcar ponto de feira</SheetTitle>
          <SheetDescription className="text-base">
            Ajude outras pessoas a encontrar feiras perto delas.
          </SheetDescription>
        </SheetHeader>

        <div className="mt-5 flex flex-col gap-5">
          <fieldset>
            <legend className="mb-2 text-sm font-extrabold text-foreground">Quem está cadastrando?</legend>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ["cliente", "🛒", "Sou cliente"],
                  ["feirante", "🧑‍🌾", "Sou feirante"],
                ] as const
              ).map(([value, emoji, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAddedBy(value)}
                  aria-pressed={addedBy === value}
                  className={`flex h-14 items-center justify-center gap-2 rounded-2xl text-base font-bold transition ${
                    addedBy === value
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  <span className="text-xl">{emoji}</span> {label}
                </button>
              ))}
            </div>
          </fieldset>

          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-extrabold">Nome da feira</span>
            <input
              className={inputClass}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex.: Feira da Rua das Flores"
            />
          </label>

          {addedBy === "feirante" && (
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-extrabold">Nome da sua banca (opcional)</span>
              <input
                className={inputClass}
                value={bancaName}
                onChange={(e) => setBancaName(e.target.value)}
                placeholder="Ex.: Banca do Seu Antônio"
              />
            </label>
          )}

          <div className="flex flex-col gap-1.5">
            <label htmlFor="feira-endereco" className="text-sm font-extrabold">
              Endereço
            </label>
            <div className="relative">
              <input
                id="feira-endereco"
                className={`${inputClass} pr-12`}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Rua, número e bairro"
              />
              {busy === "geo" && (
                <Loader2 size={20} className="absolute right-4 top-3.5 animate-spin text-muted-foreground" />
              )}
            </div>

            <div
              className={`mt-1 flex items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold ${
                position ? "bg-accent text-accent-foreground" : "bg-feira-orange-light text-foreground"
              }`}
            >
              <MapPin size={16} className="shrink-0" />
              {position ? "Local marcado no mapa ✔" : "Local ainda não marcado no mapa"}
            </div>

            {hasMapsKey && (
              <div className="mt-1 grid grid-cols-3 gap-2">
                <button type="button" onClick={onPickOnMap} className="map-action">
                  <Crosshair size={18} /> Tocar no mapa
                </button>
                <button type="button" onClick={findAddress} disabled={busy !== null} className="map-action">
                  <Search size={18} /> Achar endereço
                </button>
                <button type="button" onClick={useMyLocation} disabled={busy !== null} className="map-action">
                  <LocateFixed size={18} /> Estou aqui
                </button>
              </div>
            )}
          </div>

          <fieldset>
            <legend className="mb-2 text-sm font-extrabold">Dias da feira</legend>
            <div className="flex flex-wrap gap-2">
              {DAYS.map((d) => {
                const active = days.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setDays((prev) => (active ? prev.filter((x) => x !== d) : [...prev, d]))}
                    className={`h-11 rounded-full px-4 text-sm font-bold transition ${
                      active ? "bg-secondary text-secondary-foreground shadow" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className="grid grid-cols-2 gap-3">
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-extrabold">Começa às</span>
              <input type="time" className={inputClass} value={start} onChange={(e) => setStart(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-extrabold">Termina às</span>
              <input type="time" className={inputClass} value={end} onChange={(e) => setEnd(e.target.value)} />
            </label>
          </div>

          <button
            type="button"
            onClick={save}
            className="gradient-green h-14 rounded-2xl text-lg font-extrabold text-primary-foreground shadow-md transition active:scale-[0.98]"
          >
            Salvar ponto de feira
          </button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
