import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Feira, feiras as officialFeiras, defaultFeiraImage } from "@/data/mockData";
import { newId, usePersistentState } from "@/lib/storage";

export type UserRole = "cliente" | "feirante";

export interface LatLng {
  lat: number;
  lng: number;
}

export type NewFeira = Pick<Feira, "name" | "address" | "days" | "hours" | "lat" | "lng" | "addedBy" | "bancaName">;

interface FeirasContextType {
  feiras: Feira[];
  addFeira: (f: NewFeira) => Feira;
  removeFeira: (id: string) => void;
  userLocation: LatLng | null;
  requestLocation: () => Promise<LatLng | null>;
  role: UserRole;
  setRole: (r: UserRole) => void;
}

const FeirasContext = createContext<FeirasContextType | undefined>(undefined);

/** Distância em km entre dois pontos (fórmula de Haversine). */
export function distanceKm(a: LatLng, b: LatLng) {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export const formatKm = (km: number) => (km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1).replace(".", ",")} km`);

export function FeirasProvider({ children }: { children: ReactNode }) {
  const [custom, setCustom] = usePersistentState<Feira[]>("feiraapp:feiras-comunidade", []);
  const [role, setRole] = usePersistentState<UserRole>("feiraapp:perfil-tipo", "cliente");
  const [userLocation, setUserLocation] = useState<LatLng | null>(null);

  const requestLocation = () =>
    new Promise<LatLng | null>((resolve) => {
      if (!("geolocation" in navigator)) return resolve(null);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserLocation(loc);
          resolve(loc);
        },
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 10000 },
      );
    });

  // se o usuário já deu permissão antes, pega a localização sem perguntar de novo
  useEffect(() => {
    navigator.permissions
      ?.query({ name: "geolocation" as PermissionName })
      .then((p) => {
        if (p.state === "granted") requestLocation();
      })
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const withDistance = (f: Feira): Feira =>
    userLocation && f.lat != null && f.lng != null
      ? { ...f, distance: formatKm(distanceKm(userLocation, { lat: f.lat, lng: f.lng })) }
      : f;

  const all = [...officialFeiras, ...custom].map(withDistance);
  const feiras = userLocation
    ? [...all].sort((a, b) => parseDistance(a.distance) - parseDistance(b.distance))
    : all;

  const addFeira = (f: NewFeira) => {
    const feira: Feira = {
      ...f,
      id: `c-${newId()}`,
      image: defaultFeiraImage,
      feirantes: [],
      distance: "",
      source: "comunidade",
    };
    setCustom((prev) => [...prev, feira]);
    return feira;
  };

  const removeFeira = (id: string) => setCustom((prev) => prev.filter((f) => f.id !== id));

  return (
    <FeirasContext.Provider value={{ feiras, addFeira, removeFeira, userLocation, requestLocation, role, setRole }}>
      {children}
    </FeirasContext.Provider>
  );
}

function parseDistance(d: string) {
  if (!d) return Number.POSITIVE_INFINITY;
  const n = parseFloat(d.replace(",", "."));
  return d.endsWith(" m") ? n / 1000 : n;
}

export const useFeiras = () => {
  const ctx = useContext(FeirasContext);
  if (!ctx) throw new Error("useFeiras must be used within FeirasProvider");
  return ctx;
};
