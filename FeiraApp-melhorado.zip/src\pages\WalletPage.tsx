import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Plus, Star, Trash2, ShieldCheck, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/common";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  PaymentMethod,
  PaymentType,
  describeMethod,
  detectCardBrand,
  isValidCardNumber,
  isValidExpiry,
  paymentTypeInfo,
  useWallet,
} from "@/contexts/WalletContext";

const VALE_BRANDS = ["Alelo", "Pluxee (Sodexo)", "Ticket", "VR", "Ben", "Caju", "Flash"];

const inputClass =
  "h-12 w-full rounded-2xl border border-input bg-card px-4 text-base font-medium text-foreground outline-none placeholder:text-muted-foreground focus:ring-4 focus:ring-ring/30";

export default function WalletPage() {
  const { methods, defaultMethod, setDefault, removeMethod } = useWallet();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [adding, setAdding] = useState(params.get("novo") === "1");
  const [toRemove, setToRemove] = useState<PaymentMethod | null>(null);
  const returnTo = params.get("voltar");

  return (
    <div className="min-h-screen pb-44">
      <PageHeader title="Carteira" subtitle="Suas formas de pagamento" back />

      <div className="px-4 pt-4">
        {/* Cartão de destaque com a forma principal */}
        <div className="gradient-green relative overflow-hidden rounded-3xl p-5 text-primary-foreground shadow-card-hover">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10" />
          <div className="absolute -bottom-14 right-10 h-32 w-32 rounded-full bg-white/10" />
          <p className="text-sm font-bold uppercase tracking-wider opacity-80">Forma principal</p>
          {defaultMethod ? (
            <>
              <p className="mt-3 text-3xl">{paymentTypeInfo[defaultMethod.type].emoji}</p>
              <p className="mt-1 text-xl font-extrabold">{defaultMethod.nickname}</p>
              <p className="text-base opacity-90">{describeMethod(defaultMethod)}</p>
            </>
          ) : (
            <>
              <p className="mt-3 text-xl font-extrabold">Nenhuma ainda</p>
              <p className="text-base opacity-90">Adicione Pix, cartão, vale ou dinheiro.</p>
            </>
          )}
        </div>

        {returnTo && methods.length > 0 && (
          <button
            onClick={() => navigate(returnTo)}
            className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary text-base font-extrabold text-secondary-foreground"
          >
            <ArrowLeft size={18} /> Voltar ao pedido
          </button>
        )}

        <h2 className="mt-6 text-lg font-extrabold">Formas salvas</h2>
        <div className="mt-3 flex flex-col gap-2">
          {methods.length === 0 && (
            <p className="rounded-3xl bg-muted/60 p-5 text-center text-base text-muted-foreground">
              Sua carteira está vazia.
            </p>
          )}
          {methods.map((m) => (
            <div key={m.id} className="rounded-3xl bg-card p-3 shadow-card ring-1 ring-border/60">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent text-2xl">
                  {paymentTypeInfo[m.type].emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 truncate text-base font-bold">
                    {m.nickname}
                    {m.isDefault && (
                      <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
                        Principal
                      </span>
                    )}
                  </p>
                  <p className="truncate text-sm text-muted-foreground">{describeMethod(m)}</p>
                  {m.expiry && <p className="text-xs text-muted-foreground">Validade {m.expiry}</p>}
                </div>
              </div>
              <div className="mt-2 flex gap-2">
                {!m.isDefault && (
                  <button
                    onClick={() => {
                      setDefault(m.id);
                      toast.success(`${m.nickname} agora é a forma principal`);
                    }}
                    className="flex h-10 flex-1 items-center justify-center gap-1 rounded-xl bg-muted text-sm font-bold"
                  >
                    <Star size={15} /> Tornar principal
                  </button>
                )}
                <button
                  onClick={() => setToRemove(m)}
                  className="flex h-10 items-center justify-center gap-1 rounded-xl px-4 text-sm font-bold text-destructive ring-1 ring-destructive/30"
                >
                  <Trash2 size={15} /> Remover
                </button>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={() => setAdding(true)}
          className="gradient-orange mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-2xl text-base font-extrabold text-secondary-foreground shadow-md"
        >
          <Plus size={22} strokeWidth={3} /> Adicionar forma de pagamento
        </button>

        <p className="mt-4 flex items-start gap-2 rounded-2xl bg-accent/60 p-3 text-sm text-accent-foreground">
          <ShieldCheck size={18} className="mt-0.5 shrink-0" />
          Por segurança, guardamos só a bandeira e os 4 últimos números do cartão. O código de segurança (CVV) é pedido
          apenas na hora de pagar.
        </p>
      </div>

      <AddPaymentSheet
        open={adding}
        onOpenChange={setAdding}
        onAdded={() => {
          setAdding(false);
          if (returnTo) navigate(returnTo);
        }}
      />

      <AlertDialog open={!!toRemove} onOpenChange={(o) => !o && setToRemove(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Remover {toRemove?.nickname}?</AlertDialogTitle>
            <AlertDialogDescription className="text-base">
              Esta forma de pagamento sai da sua carteira. Você pode adicioná-la de novo depois.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-12 rounded-2xl text-base">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="h-12 rounded-2xl bg-destructive text-base text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (toRemove) removeMethod(toRemove.id);
                setToRemove(null);
              }}
            >
              Remover
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ---------------------------------------------------------------------------

function formatCardNumber(value: string) {
  return value
    .replace(/\D/g, "")
    .slice(0, 19)
    .replace(/(\d{4})(?=\d)/g, "$1 ");
}

function formatExpiry(value: string) {
  const d = value.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
}

function AddPaymentSheet({
  open,
  onOpenChange,
  onAdded,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onAdded: () => void;
}) {
  const { addMethod } = useWallet();
  const [type, setType] = useState<PaymentType | null>(null);
  const [nickname, setNickname] = useState("");
  const [number, setNumber] = useState("");
  const [holder, setHolder] = useState("");
  const [expiry, setExpiry] = useState("");
  const [valeBrand, setValeBrand] = useState(VALE_BRANDS[0]);
  const [changeFor, setChangeFor] = useState("");
  const [makeDefault, setMakeDefault] = useState(false);

  useEffect(() => {
    if (!open) {
      setType(null);
      setNickname("");
      setNumber("");
      setHolder("");
      setExpiry("");
      setChangeFor("");
      setMakeDefault(false);
    }
  }, [open]);

  const digits = number.replace(/\D/g, "");
  const isCard = type === "credito" || type === "debito";
  const brand = isCard ? detectCardBrand(digits) : undefined;

  const save = () => {
    if (!type) return;
    const info = paymentTypeInfo[type];

    if (isCard) {
      if (!isValidCardNumber(digits)) return toast.error("Número do cartão inválido. Confira os números.");
      if (!holder.trim()) return toast.error("Digite o nome impresso no cartão");
      if (!isValidExpiry(expiry)) return toast.error("Validade inválida ou vencida (use MM/AA)");
      addMethod(
        {
          type,
          nickname: nickname.trim() || `${brand ?? "Cartão"} ${type === "credito" ? "crédito" : "débito"}`,
          brand: brand ?? "Cartão",
          last4: digits.slice(-4),
          holder: holder.trim().toUpperCase(),
          expiry,
        },
        makeDefault,
      );
    } else if (type === "vale") {
      if (digits.length < 12) return toast.error("Digite o número do cartão do vale");
      addMethod(
        { type, nickname: nickname.trim() || valeBrand, brand: valeBrand, last4: digits.slice(-4) },
        makeDefault,
      );
    } else if (type === "dinheiro") {
      const troco = Number(changeFor.replace(",", "."));
      addMethod(
        { type, nickname: nickname.trim() || info.label, changeFor: troco > 0 ? troco : undefined },
        makeDefault,
      );
    } else {
      addMethod({ type, nickname: nickname.trim() || info.label }, makeDefault);
    }

    toast.success("Forma de pagamento adicionada à carteira!");
    onAdded();
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="mx-auto max-h-[92vh] max-w-lg overflow-y-auto rounded-t-3xl pb-8">
        <SheetHeader className="text-left">
          <SheetTitle className="text-2xl font-extrabold">
            {type ? paymentTypeInfo[type].label : "Nova forma de pagamento"}
          </SheetTitle>
          <SheetDescription className="text-base">
            {type ? paymentTypeInfo[type].description : "Como você prefere pagar?"}
          </SheetDescription>
        </SheetHeader>

        {!type && (
          <div className="mt-5 flex flex-col gap-2">
            {(Object.keys(paymentTypeInfo) as PaymentType[]).map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className="flex items-center gap-3 rounded-2xl bg-card p-3 text-left shadow-card ring-1 ring-border transition active:scale-[0.98]"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-2xl">
                  {paymentTypeInfo[t].emoji}
                </span>
                <span>
                  <span className="block text-base font-bold">{paymentTypeInfo[t].label}</span>
                  <span className="block text-sm text-muted-foreground">{paymentTypeInfo[t].description}</span>
                </span>
              </button>
            ))}
          </div>
        )}

        {type && (
          <div className="mt-5 flex flex-col gap-4">
            {isCard && (
              <>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-extrabold">Número do cartão</span>
                  <div className="relative">
                    <input
                      className={`${inputClass} pr-28 tracking-wider`}
                      inputMode="numeric"
                      autoComplete="cc-number"
                      value={number}
                      onChange={(e) => setNumber(formatCardNumber(e.target.value))}
                      placeholder="0000 0000 0000 0000"
                    />
                    {brand && (
                      <span className="absolute right-3 top-3 rounded-lg bg-accent px-2 py-0.5 text-sm font-bold text-accent-foreground">
                        {brand}
                      </span>
                    )}
                  </div>
                </label>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-extrabold">Nome impresso no cartão</span>
                  <input
                    className={`${inputClass} uppercase`}
                    autoComplete="cc-name"
                    value={holder}
                    onChange={(e) => setHolder(e.target.value)}
                    placeholder="MARIA DA SILVA"
                  />
                </label>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-extrabold">Validade</span>
                  <input
                    className={inputClass}
                    inputMode="numeric"
                    autoComplete="cc-exp"
                    value={expiry}
                    onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                    placeholder="MM/AA"
                  />
                </label>
              </>
            )}

            {type === "vale" && (
              <>
                <fieldset>
                  <legend className="mb-2 text-sm font-extrabold">Bandeira</legend>
                  <div className="flex flex-wrap gap-2">
                    {VALE_BRANDS.map((b) => (
                      <button
                        key={b}
                        type="button"
                        aria-pressed={valeBrand === b}
                        onClick={() => setValeBrand(b)}
                        className={`h-11 rounded-full px-4 text-sm font-bold ${
                          valeBrand === b ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </fieldset>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-extrabold">Número do cartão do vale</span>
                  <input
                    className={`${inputClass} tracking-wider`}
                    inputMode="numeric"
                    value={number}
                    onChange={(e) => setNumber(formatCardNumber(e.target.value))}
                    placeholder="0000 0000 0000 0000"
                  />
                </label>
              </>
            )}

            {type === "pix" && (
              <p className="rounded-2xl bg-accent/60 p-4 text-base text-accent-foreground">
                Ao fechar o pedido, mostramos um QR Code e o código “copia e cola” para você pagar pelo app do seu
                banco. Não é preciso cadastrar nada.
              </p>
            )}

            {type === "dinheiro" && (
              <label className="flex flex-col gap-1.5">
                <span className="text-sm font-extrabold">Precisa de troco? Para quanto? (opcional)</span>
                <input
                  className={inputClass}
                  inputMode="decimal"
                  value={changeFor}
                  onChange={(e) => setChangeFor(e.target.value.replace(/[^\d,]/g, ""))}
                  placeholder="Ex.: 100,00"
                />
              </label>
            )}

            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-extrabold">Apelido (opcional)</span>
              <input
                className={inputClass}
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="Ex.: Cartão do banco, Vale da firma"
              />
            </label>

            <label className="flex items-center gap-3 rounded-2xl bg-muted/60 p-3">
              <input
                type="checkbox"
                checked={makeDefault}
                onChange={(e) => setMakeDefault(e.target.checked)}
                className="h-6 w-6 accent-[hsl(var(--primary))]"
              />
              <span className="text-base font-semibold">Usar como forma principal</span>
            </label>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setType(null)}
                className="h-14 rounded-2xl bg-muted px-5 text-base font-bold"
              >
                Voltar
              </button>
              <button
                type="button"
                onClick={save}
                className="gradient-green h-14 flex-1 rounded-2xl text-lg font-extrabold text-primary-foreground shadow-md"
              >
                Salvar na carteira
              </button>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
