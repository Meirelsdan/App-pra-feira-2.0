import tomates from "@/assets/products/tomates.jpg";
import alface from "@/assets/products/alface.jpg";
import bananas from "@/assets/products/bananas.jpg";
import laranjas from "@/assets/products/laranjas.jpg";
import ervas from "@/assets/products/ervas.jpg";
import morangos from "@/assets/products/morangos.jpg";
import heroFeira from "@/assets/hero-feira.jpg";
import cestaProdutos from "@/assets/cesta-produtos.jpg";

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  emoji: string;
  image?: string;
  category: string;
  group: string;
  feiranteId: string;
  organic: boolean;
}

export interface Feirante {
  id: string;
  name: string;
  rating: number;
  reviews: number;
  description: string;
  avatar: string;
  distance: string;
  deliveryTime: string;
  deliveryFee: number;
  tags: string[];
}

export interface Feira {
  id: string;
  name: string;
  address: string;
  days: string;
  hours: string;
  image: string;
  feirantes: string[];
  distance: string;
  lat?: number;
  lng?: number;
  /** "oficial" = cadastrada pelo app; "comunidade" = adicionada por cliente ou feirante */
  source: "oficial" | "comunidade";
  addedBy?: "cliente" | "feirante";
  bancaName?: string;
}

export interface CategoryGroup {
  id: string;
  name: string;
}

export interface Category {
  id: string;
  name: string;
  emoji: string;
  /** cor de fundo (HSL sem o hsl()) usada nos blocos do catálogo */
  tint: string;
  groups: CategoryGroup[];
}

export const defaultFeiraImage = cestaProdutos;

// ---------------------------------------------------------------------------
// Catálogo: cada categoria é dividida em tipos (grupos)
// ---------------------------------------------------------------------------
export const categories: Category[] = [
  {
    id: "frutas",
    name: "Frutas",
    emoji: "🍎",
    tint: "0 75% 94%",
    groups: [
      { id: "citricas", name: "Cítricas" },
      { id: "tropicais", name: "Tropicais" },
      { id: "vermelhas", name: "Vermelhas e uvas" },
      { id: "pomar", name: "De pomar e caroço" },
      { id: "meloes", name: "Melões e melancias" },
    ],
  },
  {
    id: "verduras",
    name: "Verduras e Folhas",
    emoji: "🥬",
    tint: "110 45% 91%",
    groups: [
      { id: "salada", name: "Folhas para salada" },
      { id: "refogar", name: "Para refogar e cozinhar" },
    ],
  },
  {
    id: "legumes",
    name: "Legumes",
    emoji: "🍅",
    tint: "15 80% 93%",
    groups: [
      { id: "frutos", name: "Tomates e legumes-fruto" },
      { id: "pimentoes", name: "Pimentões" },
      { id: "aboboras", name: "Abóboras" },
    ],
  },
  {
    id: "raizes",
    name: "Raízes e Tubérculos",
    emoji: "🥔",
    tint: "35 55% 90%",
    groups: [
      { id: "raizes", name: "Raízes e tubérculos" },
      { id: "bulbos", name: "Cebola e alho" },
    ],
  },
  {
    id: "temperos",
    name: "Temperos e Ervas",
    emoji: "🌿",
    tint: "140 35% 90%",
    groups: [
      { id: "frescas", name: "Ervas frescas" },
      { id: "secos", name: "Temperos secos" },
      { id: "pimentas", name: "Pimentas" },
    ],
  },
  {
    id: "ovos",
    name: "Ovos e Laticínios",
    emoji: "🥚",
    tint: "48 85% 91%",
    groups: [
      { id: "ovos", name: "Ovos" },
      { id: "queijos", name: "Queijos" },
      { id: "laticinios", name: "Leite, manteiga e iogurte" },
    ],
  },
  {
    id: "pescados",
    name: "Peixes e Frutos do Mar",
    emoji: "🐟",
    tint: "200 70% 92%",
    groups: [
      { id: "peixes", name: "Peixes" },
      { id: "frutosdomar", name: "Frutos do mar" },
    ],
  },
  {
    id: "graos",
    name: "Grãos e Castanhas",
    emoji: "🫘",
    tint: "30 45% 89%",
    groups: [
      { id: "graos", name: "Grãos e cereais" },
      { id: "castanhas", name: "Castanhas e secos" },
    ],
  },
  {
    id: "padaria",
    name: "Pães e Bolos",
    emoji: "🍞",
    tint: "38 70% 90%",
    groups: [
      { id: "paes", name: "Pães" },
      { id: "bolos", name: "Bolos e biscoitos" },
    ],
  },
  {
    id: "doces",
    name: "Doces, Geleias e Mel",
    emoji: "🍯",
    tint: "42 90% 89%",
    groups: [
      { id: "doces", name: "Doces caseiros" },
      { id: "geleias", name: "Geleias" },
      { id: "mel", name: "Mel e derivados" },
    ],
  },
  {
    id: "lanches",
    name: "Pastel e Bebidas",
    emoji: "🥟",
    tint: "25 90% 91%",
    groups: [
      { id: "pastel", name: "Pastéis" },
      { id: "bebidas", name: "Caldo de cana e sucos" },
    ],
  },
  {
    id: "flores",
    name: "Flores e Plantas",
    emoji: "💐",
    tint: "330 70% 94%",
    groups: [
      { id: "flores", name: "Flores" },
      { id: "plantas", name: "Plantas e mudas" },
    ],
  },
  {
    id: "cestas",
    name: "Cestas e Kits",
    emoji: "🧺",
    tint: "90 35% 90%",
    groups: [{ id: "cestas", name: "Cestas e kits prontos" }],
  },
];

export const getCategory = (id: string) => categories.find((c) => c.id === id);

// ---------------------------------------------------------------------------
// Feiras
// ---------------------------------------------------------------------------
export const feiras: Feira[] = [
  {
    id: "f1",
    name: "Feira da Vila Madalena",
    address: "Rua Aspicuelta, 145 - Vila Madalena",
    days: "Terça e Sábado",
    hours: "6h às 12h",
    image: heroFeira,
    feirantes: ["fe1", "fe2", "fe3", "fe7", "fe8"],
    distance: "1.2 km",
    lat: -23.5568,
    lng: -46.6905,
    source: "oficial",
  },
  {
    id: "f2",
    name: "Feira do Pacaembu",
    address: "Praça Charles Miller - Pacaembu",
    days: "Terça, Quinta e Sábado",
    hours: "7h às 13h",
    image: cestaProdutos,
    feirantes: ["fe1", "fe4", "fe5", "fe6", "fe7"],
    distance: "2.8 km",
    lat: -23.5476,
    lng: -46.6654,
    source: "oficial",
  },
  {
    id: "f3",
    name: "Feira da Lapa",
    address: "Rua Catão, 72 - Lapa",
    days: "Segunda e Quinta",
    hours: "6h às 11h",
    image: heroFeira,
    feirantes: ["fe2", "fe3", "fe4", "fe9", "fe10"],
    distance: "3.5 km",
    lat: -23.5236,
    lng: -46.7012,
    source: "oficial",
  },
  {
    id: "f4",
    name: "Feira Orgânica do Parque da Água Branca",
    address: "Av. Francisco Matarazzo, 455 - Água Branca",
    days: "Terça, Sábado e Domingo",
    hours: "7h às 12h",
    image: cestaProdutos,
    feirantes: ["fe1", "fe3", "fe6", "fe9"],
    distance: "3.9 km",
    lat: -23.5272,
    lng: -46.6687,
    source: "oficial",
  },
  {
    id: "f5",
    name: "Feira de Pinheiros",
    address: "Praça Benedito Calixto - Pinheiros",
    days: "Quarta e Sábado",
    hours: "7h às 13h",
    image: heroFeira,
    feirantes: ["fe2", "fe5", "fe8", "fe10"],
    distance: "1.9 km",
    lat: -23.5636,
    lng: -46.6821,
    source: "oficial",
  },
];

// ---------------------------------------------------------------------------
// Feirantes
// ---------------------------------------------------------------------------
export const feirantes: Feirante[] = [
  {
    id: "fe1",
    name: "Dona Maria - Horta Orgânica",
    rating: 4.9,
    reviews: 238,
    description: "Produtora familiar há 20 anos. Tudo orgânico, direto da roça!",
    avatar: "👩‍🌾",
    distance: "1.2 km",
    deliveryTime: "30-45 min",
    deliveryFee: 5.99,
    tags: ["Orgânico", "Familiar"],
  },
  {
    id: "fe2",
    name: "Seu João - Frutas Tropicais",
    rating: 4.7,
    reviews: 156,
    description: "As melhores frutas da região! Colhidas no dia anterior.",
    avatar: "👨‍🌾",
    distance: "1.5 km",
    deliveryTime: "25-40 min",
    deliveryFee: 4.99,
    tags: ["Frutas", "Frescas"],
  },
  {
    id: "fe3",
    name: "Sítio Boa Vista",
    rating: 4.8,
    reviews: 312,
    description: "Verduras, legumes e ervas frescas do nosso sítio em Ibiúna.",
    avatar: "🏡",
    distance: "2.0 km",
    deliveryTime: "35-50 min",
    deliveryFee: 6.99,
    tags: ["Verduras", "Legumes"],
  },
  {
    id: "fe4",
    name: "Recanto Natural",
    rating: 4.6,
    reviews: 89,
    description: "Grãos, castanhas, geleias, doces e mel de produtores locais.",
    avatar: "🌻",
    distance: "3.0 km",
    deliveryTime: "40-55 min",
    deliveryFee: 7.99,
    tags: ["Artesanal", "Natural"],
  },
  {
    id: "fe5",
    name: "Peixaria do Zé",
    rating: 4.8,
    reviews: 174,
    description: "Peixes e frutos do mar fresquinhos, chegam de madrugada do litoral.",
    avatar: "🐟",
    distance: "1.9 km",
    deliveryTime: "30-45 min",
    deliveryFee: 6.49,
    tags: ["Pescados", "Fresco do dia"],
  },
  {
    id: "fe6",
    name: "Queijaria Serra da Canastra",
    rating: 4.9,
    reviews: 201,
    description: "Queijos artesanais de Minas, ovos caipira e laticínios da fazenda.",
    avatar: "🧀",
    distance: "2.8 km",
    deliveryTime: "35-50 min",
    deliveryFee: 6.99,
    tags: ["Queijos", "Ovos caipira"],
  },
  {
    id: "fe7",
    name: "Pastelaria da Dona Ana",
    rating: 4.7,
    reviews: 412,
    description: "O pastel de feira mais famoso do bairro e caldo de cana geladinho.",
    avatar: "🥟",
    distance: "1.2 km",
    deliveryTime: "20-35 min",
    deliveryFee: 3.99,
    tags: ["Pastel", "Caldo de cana"],
  },
  {
    id: "fe8",
    name: "Flores da Tia Rosa",
    rating: 4.8,
    reviews: 97,
    description: "Flores do campo, buquês e mudas para sua casa ficar mais bonita.",
    avatar: "💐",
    distance: "1.9 km",
    deliveryTime: "30-45 min",
    deliveryFee: 5.49,
    tags: ["Flores", "Mudas"],
  },
  {
    id: "fe9",
    name: "Padaria Caseira Vó Lurdes",
    rating: 4.9,
    reviews: 263,
    description: "Pães, bolos e biscoitos feitos no forno a lenha, como antigamente.",
    avatar: "🍞",
    distance: "3.5 km",
    deliveryTime: "35-50 min",
    deliveryFee: 5.99,
    tags: ["Caseiro", "Forno a lenha"],
  },
  {
    id: "fe10",
    name: "Raízes do Vale",
    rating: 4.6,
    reviews: 118,
    description: "Batatas, mandioca, cebola, alho e temperos moídos na hora.",
    avatar: "🥔",
    distance: "3.5 km",
    deliveryTime: "40-55 min",
    deliveryFee: 6.49,
    tags: ["Raízes", "Temperos"],
  },
];

// ---------------------------------------------------------------------------
// Produtos
// ---------------------------------------------------------------------------
const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

type ProductRow = [
  name: string,
  price: number,
  unit: string,
  emoji: string,
  feiranteId: string,
  organic?: boolean,
  image?: string,
];

function build(category: string, group: string, rows: ProductRow[]): Product[] {
  return rows.map(([name, price, unit, emoji, feiranteId, organic = false, image]) => ({
    id: slug(name),
    name,
    price,
    unit,
    emoji,
    image,
    category,
    group,
    feiranteId,
    organic,
  }));
}

export const products: Product[] = [
  // Frutas
  ...build("frutas", "citricas", [
    ["Laranja Pera", 6.5, "kg", "🍊", "fe2", true, laranjas],
    ["Laranja Lima", 7.9, "kg", "🍊", "fe2"],
    ["Laranja Bahia", 8.5, "kg", "🍊", "fe2"],
    ["Tangerina Ponkan", 7.5, "kg", "🍊", "fe2"],
    ["Mexerica Murcote", 8.9, "kg", "🍊", "fe2"],
    ["Limão Taiti", 5.9, "kg", "🍋", "fe2"],
    ["Limão Siciliano", 12.9, "kg", "🍋", "fe2"],
  ]),
  ...build("frutas", "tropicais", [
    ["Banana Nanica", 5.9, "kg", "🍌", "fe2", false, bananas],
    ["Banana Prata", 7.9, "kg", "🍌", "fe2", false, bananas],
    ["Banana da Terra", 8.9, "kg", "🍌", "fe2"],
    ["Banana Maçã", 9.9, "kg", "🍌", "fe1", true],
    ["Abacaxi Pérola", 9.0, "un", "🍍", "fe2"],
    ["Manga Palmer", 8.9, "kg", "🥭", "fe2"],
    ["Manga Tommy", 7.9, "kg", "🥭", "fe2"],
    ["Mamão Papaya", 9.9, "kg", "🥭", "fe2"],
    ["Mamão Formosa", 6.9, "kg", "🥭", "fe2"],
    ["Maracujá Azedo", 11.9, "kg", "🟡", "fe2"],
    ["Goiaba Vermelha", 9.9, "kg", "🍐", "fe1", true],
    ["Abacate", 9.9, "kg", "🥑", "fe2"],
    ["Coco Verde", 6.0, "un", "🥥", "fe2"],
    ["Kiwi", 16.9, "kg", "🥝", "fe2"],
  ]),
  ...build("frutas", "vermelhas", [
    ["Morango Orgânico", 12.9, "bandeja", "🍓", "fe1", true, morangos],
    ["Morango", 9.9, "bandeja", "🍓", "fe2"],
    ["Uva Niágara", 11.9, "kg", "🍇", "fe2"],
    ["Uva Thompson sem semente", 14.9, "kg", "🍇", "fe2"],
    ["Mirtilo (Blueberry)", 14.9, "bandeja", "🫐", "fe1", true],
    ["Amora", 13.9, "bandeja", "🫐", "fe1", true],
    ["Framboesa", 16.9, "bandeja", "🍓", "fe1"],
    ["Cereja", 39.9, "kg", "🍒", "fe2"],
  ]),
  ...build("frutas", "pomar", [
    ["Maçã Gala", 9.9, "kg", "🍎", "fe2"],
    ["Maçã Fuji", 11.9, "kg", "🍎", "fe2"],
    ["Maçã Verde", 14.9, "kg", "🍏", "fe2"],
    ["Pera Williams", 12.9, "kg", "🍐", "fe2"],
    ["Pêssego", 15.9, "kg", "🍑", "fe2"],
    ["Ameixa", 13.9, "kg", "🍑", "fe2"],
    ["Caqui Rama Forte", 9.9, "kg", "🍅", "fe2"],
  ]),
  ...build("frutas", "meloes", [
    ["Melancia", 3.5, "kg", "🍉", "fe2"],
    ["Melão Amarelo", 5.9, "kg", "🍈", "fe2"],
    ["Melão Cantaloupe", 9.9, "un", "🍈", "fe2"],
  ]),

  // Verduras
  ...build("verduras", "salada", [
    ["Alface Crespa", 3.5, "un", "🥬", "fe3", false, alface],
    ["Alface Americana", 4.5, "un", "🥬", "fe1", true, alface],
    ["Alface Roxa", 4.0, "un", "🥬", "fe3"],
    ["Rúcula", 4.0, "maço", "🥬", "fe1", true],
    ["Agrião", 4.5, "maço", "🥬", "fe3"],
    ["Almeirão", 4.0, "maço", "🥬", "fe3"],
    ["Chicória", 4.0, "maço", "🥬", "fe3"],
  ]),
  ...build("verduras", "refogar", [
    ["Couve Manteiga", 4.0, "maço", "🥬", "fe3"],
    ["Espinafre", 5.0, "maço", "🥬", "fe1", true],
    ["Acelga", 6.0, "un", "🥬", "fe3"],
    ["Repolho Verde", 4.5, "un", "🥬", "fe3"],
    ["Repolho Roxo", 5.5, "un", "🥬", "fe3"],
    ["Brócolis Ninja", 8.9, "un", "🥦", "fe3"],
    ["Couve-flor", 8.5, "un", "🥦", "fe3"],
    ["Alho-poró", 6.9, "un", "🥬", "fe1", true],
  ]),

  // Legumes
  ...build("legumes", "frutos", [
    ["Tomate Orgânico", 8.9, "kg", "🍅", "fe1", true, tomates],
    ["Tomate Italiano", 7.9, "kg", "🍅", "fe3", false, tomates],
    ["Tomate Cereja", 9.9, "bandeja", "🍅", "fe3", false, tomates],
    ["Abobrinha Italiana", 6.9, "kg", "🥒", "fe3"],
    ["Berinjela", 6.5, "kg", "🍆", "fe3"],
    ["Pepino Japonês", 6.9, "kg", "🥒", "fe3"],
    ["Chuchu", 3.9, "kg", "🥒", "fe3"],
    ["Quiabo", 11.9, "kg", "🫛", "fe3"],
    ["Jiló", 9.9, "kg", "🫛", "fe3"],
    ["Vagem", 12.9, "kg", "🫛", "fe1", true],
    ["Ervilha Torta", 18.9, "kg", "🫛", "fe1"],
    ["Milho Verde", 2.5, "espiga", "🌽", "fe3"],
  ]),
  ...build("legumes", "pimentoes", [
    ["Pimentão Verde", 7.9, "kg", "🫑", "fe3"],
    ["Pimentão Vermelho", 14.9, "kg", "🫑", "fe3"],
    ["Pimentão Amarelo", 14.9, "kg", "🫑", "fe3"],
  ]),
  ...build("legumes", "aboboras", [
    ["Abóbora Cabotiá", 4.9, "kg", "🎃", "fe3"],
    ["Abóbora Moranga", 4.5, "kg", "🎃", "fe3"],
    ["Abóbora Paulista", 5.5, "kg", "🎃", "fe1", true],
  ]),

  // Raízes e tubérculos
  ...build("raizes", "raizes", [
    ["Batata Inglesa", 5.9, "kg", "🥔", "fe10"],
    ["Batata Doce", 5.5, "kg", "🍠", "fe10"],
    ["Batata Doce Roxa", 6.9, "kg", "🍠", "fe10"],
    ["Mandioca", 5.9, "kg", "🥔", "fe10"],
    ["Mandioquinha", 14.9, "kg", "🥔", "fe10"],
    ["Inhame", 8.9, "kg", "🥔", "fe10"],
    ["Cará", 8.9, "kg", "🥔", "fe10"],
    ["Cenoura", 4.9, "kg", "🥕", "fe3"],
    ["Beterraba", 4.9, "kg", "🍠", "fe3"],
    ["Rabanete", 5.0, "maço", "🍠", "fe1", true],
    ["Gengibre", 19.9, "kg", "🫚", "fe10"],
  ]),
  ...build("raizes", "bulbos", [
    ["Cebola", 4.9, "kg", "🧅", "fe10"],
    ["Cebola Roxa", 6.9, "kg", "🧅", "fe10"],
    ["Alho", 34.9, "kg", "🧄", "fe10"],
    ["Alho Descascado", 9.9, "pote 200g", "🧄", "fe10"],
  ]),

  // Temperos e ervas
  ...build("temperos", "frescas", [
    ["Cheiro Verde", 2.5, "maço", "🌿", "fe1", true, ervas],
    ["Salsinha", 2.0, "maço", "🌿", "fe3", false, ervas],
    ["Cebolinha", 2.0, "maço", "🌿", "fe3"],
    ["Coentro", 2.5, "maço", "🌿", "fe3"],
    ["Manjericão", 3.5, "maço", "🌿", "fe1", true],
    ["Hortelã", 3.0, "maço", "🌿", "fe1", true],
    ["Alecrim", 3.0, "maço", "🌿", "fe3"],
    ["Tomilho", 3.5, "maço", "🌿", "fe3"],
    ["Louro Fresco", 3.0, "maço", "🍃", "fe3"],
  ]),
  ...build("temperos", "secos", [
    ["Pimenta-do-reino Moída", 6.0, "100g", "🧂", "fe10"],
    ["Colorau", 4.0, "100g", "🧂", "fe10"],
    ["Cúrcuma (Açafrão-da-terra)", 6.5, "100g", "🧂", "fe10"],
    ["Orégano", 5.0, "50g", "🌿", "fe10"],
    ["Páprica Defumada", 7.5, "100g", "🧂", "fe10"],
    ["Cominho", 5.5, "100g", "🧂", "fe10"],
    ["Sal Grosso com Ervas", 8.0, "pote", "🧂", "fe10"],
  ]),
  ...build("temperos", "pimentas", [
    ["Pimenta Dedo-de-moça", 3.5, "bandeja", "🌶️", "fe10"],
    ["Pimenta Biquinho", 5.0, "bandeja", "🌶️", "fe10"],
    ["Pimenta Malagueta", 4.0, "bandeja", "🌶️", "fe10"],
    ["Pimenta Biquinho em Conserva", 14.9, "pote", "🫙", "fe4"],
  ]),

  // Ovos e laticínios
  ...build("ovos", "ovos", [
    ["Ovos Brancos", 12.9, "dúzia", "🥚", "fe6"],
    ["Ovos Vermelhos", 14.0, "dúzia", "🥚", "fe6"],
    ["Ovos Caipira", 16.9, "dúzia", "🥚", "fe6", true],
    ["Ovos de Codorna", 7.9, "bandeja 30un", "🥚", "fe6"],
  ]),
  ...build("ovos", "queijos", [
    ["Queijo Minas Frescal", 19.9, "peça 500g", "🧀", "fe6"],
    ["Queijo Canastra Meia-cura", 69.9, "kg", "🧀", "fe6"],
    ["Queijo Coalho", 39.9, "kg", "🧀", "fe6"],
    ["Muçarela", 44.9, "kg", "🧀", "fe6"],
    ["Ricota Fresca", 12.9, "un", "🧀", "fe6"],
    ["Requeijão Caseiro", 14.9, "pote", "🥛", "fe6"],
  ]),
  ...build("ovos", "laticinios", [
    ["Manteiga Caseira", 18.9, "pote 250g", "🧈", "fe6"],
    ["Iogurte Natural", 9.9, "pote 500g", "🥛", "fe6"],
    ["Leite Fresco", 7.5, "litro", "🥛", "fe6"],
    ["Coalhada", 8.9, "pote", "🥛", "fe6"],
  ]),

  // Pescados
  ...build("pescados", "peixes", [
    ["Filé de Tilápia", 49.9, "kg", "🐟", "fe5"],
    ["Sardinha", 14.9, "kg", "🐟", "fe5"],
    ["Pescada Amarela", 44.9, "kg", "🐟", "fe5"],
    ["Merluza", 34.9, "kg", "🐟", "fe5"],
    ["Salmão em Posta", 89.9, "kg", "🐟", "fe5"],
  ]),
  ...build("pescados", "frutosdomar", [
    ["Camarão Cinza Médio", 69.9, "kg", "🦐", "fe5"],
    ["Camarão Rosa Grande", 119.9, "kg", "🦐", "fe5"],
    ["Lula em Anéis", 54.9, "kg", "🦑", "fe5"],
    ["Mexilhão", 39.9, "kg", "🦪", "fe5"],
    ["Polvo", 99.9, "kg", "🐙", "fe5"],
  ]),

  // Grãos e castanhas
  ...build("graos", "graos", [
    ["Feijão Carioca", 8.9, "kg", "🫘", "fe4"],
    ["Feijão Preto", 9.9, "kg", "🫘", "fe4"],
    ["Feijão Fradinho", 12.9, "kg", "🫘", "fe4"],
    ["Arroz Integral Orgânico", 9.9, "kg", "🍚", "fe4", true],
    ["Grão-de-bico", 14.9, "kg", "🫘", "fe4"],
    ["Lentilha", 13.9, "kg", "🫘", "fe4"],
    ["Milho de Pipoca", 7.9, "kg", "🍿", "fe4"],
    ["Fubá Mimoso", 5.9, "kg", "🌽", "fe4"],
  ]),
  ...build("graos", "castanhas", [
    ["Amendoim Torrado", 19.9, "kg", "🥜", "fe4"],
    ["Castanha-de-caju", 69.9, "kg", "🥜", "fe4"],
    ["Castanha-do-pará", 79.9, "kg", "🌰", "fe4"],
    ["Nozes", 89.9, "kg", "🌰", "fe4"],
    ["Uva-passa", 29.9, "kg", "🍇", "fe4"],
    ["Granola Caseira", 34.9, "kg", "🥣", "fe4"],
  ]),

  // Pães e bolos
  ...build("padaria", "paes", [
    ["Pão Caseiro", 12.0, "un", "🍞", "fe9"],
    ["Pão Italiano", 15.0, "un", "🥖", "fe9"],
    ["Pão de Queijo", 39.9, "kg", "🧀", "fe9"],
    ["Broa de Milho", 3.5, "un", "🍞", "fe9"],
    ["Rosca Doce", 16.0, "un", "🥐", "fe9"],
  ]),
  ...build("padaria", "bolos", [
    ["Bolo de Fubá", 18.0, "un", "🍰", "fe9"],
    ["Bolo de Cenoura com Chocolate", 25.0, "un", "🍰", "fe9"],
    ["Bolo de Laranja", 20.0, "un", "🍰", "fe9"],
    ["Biscoito de Polvilho", 9.0, "pacote", "🥨", "fe9"],
    ["Biscoito Amanteigado", 14.0, "pacote", "🍪", "fe9"],
  ]),

  // Doces, geleias e mel
  ...build("doces", "doces", [
    ["Doce de Leite", 16.9, "pote", "🍮", "fe4"],
    ["Goiabada Cascão", 14.9, "un", "🍬", "fe4"],
    ["Cocada", 4.0, "un", "🥥", "fe4"],
    ["Pé de Moleque", 3.0, "un", "🥜", "fe4"],
    ["Paçoca Caseira", 2.5, "un", "🥜", "fe4"],
    ["Rapadura", 6.0, "un", "🍬", "fe4"],
  ]),
  ...build("doces", "geleias", [
    ["Geleia de Morango", 18.9, "pote", "🫙", "fe4"],
    ["Geleia de Jabuticaba", 22.9, "pote", "🫙", "fe4"],
    ["Geleia de Pimenta", 19.9, "pote", "🫙", "fe4"],
  ]),
  ...build("doces", "mel", [
    ["Mel Silvestre", 29.9, "pote 500g", "🍯", "fe4"],
    ["Mel de Laranjeira", 34.9, "pote 500g", "🍯", "fe4"],
    ["Melado de Cana", 15.9, "pote", "🍯", "fe4"],
  ]),

  // Pastel e bebidas
  ...build("lanches", "pastel", [
    ["Pastel de Carne", 10.0, "un", "🥟", "fe7"],
    ["Pastel de Queijo", 10.0, "un", "🥟", "fe7"],
    ["Pastel de Pizza", 11.0, "un", "🥟", "fe7"],
    ["Pastel de Palmito", 12.0, "un", "🥟", "fe7"],
    ["Pastel de Frango com Catupiry", 12.0, "un", "🥟", "fe7"],
    ["Pastel de Banana com Canela", 10.0, "un", "🥟", "fe7"],
  ]),
  ...build("lanches", "bebidas", [
    ["Caldo de Cana", 8.0, "copo 500ml", "🥤", "fe7"],
    ["Caldo de Cana com Limão", 9.0, "copo 500ml", "🥤", "fe7"],
    ["Água de Coco", 7.0, "un", "🥥", "fe7"],
    ["Suco de Laranja Natural", 10.0, "garrafa 1L", "🧃", "fe7"],
  ]),

  // Flores e plantas
  ...build("flores", "flores", [
    ["Buquê Flores do Campo", 35.0, "un", "💐", "fe8"],
    ["Rosas Vermelhas", 45.0, "dúzia", "🌹", "fe8"],
    ["Girassóis", 30.0, "maço", "🌻", "fe8"],
    ["Crisântemo em Vaso", 25.0, "vaso", "🌼", "fe8"],
  ]),
  ...build("flores", "plantas", [
    ["Orquídea", 59.9, "vaso", "🌸", "fe8"],
    ["Suculenta", 12.0, "vaso", "🪴", "fe8"],
    ["Samambaia", 39.9, "vaso", "🪴", "fe8"],
    ["Muda de Manjericão", 8.0, "vaso", "🌱", "fe8"],
    ["Muda de Alecrim", 8.0, "vaso", "🌱", "fe8"],
  ]),

  // Cestas e kits
  ...build("cestas", "cestas", [
    ["Cesta Orgânica da Semana", 79.9, "cesta", "🧺", "fe1", true],
    ["Cesta de Frutas da Estação", 59.9, "cesta", "🧺", "fe2"],
    ["Kit Sopa", 24.9, "kit", "🍲", "fe3"],
    ["Kit Salada", 19.9, "kit", "🥗", "fe3"],
    ["Kit Vitamina", 29.9, "kit", "🧃", "fe2"],
  ]),
];

export const formatPrice = (value: number) => `R$ ${value.toFixed(2).replace(".", ",")}`;
