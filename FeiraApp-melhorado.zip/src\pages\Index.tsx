import { Search, MapPin, ChevronRight, MapPinned, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import logo from "@/assets/logo-feira.png";
import heroFeira from "@/assets/hero-feira.jpg";
import { categories, feirantes, products } from "@/data/mockData";
import ProductCard from "@/components/ProductCard";
import FeiranteCard from "@/components/FeiranteCard";
import FeiraCard from "@/components/FeiraCard";
import { SectionTitle } from "@/components/common";
import { useFeiras } from "@/contexts/FeirasContext";

const seeAll = "flex items-center gap-0.5 text-sm font-extrabold text-primary";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Bom dia";
  if (h < 18) return "Boa tarde";
  return "Boa noite";
}

export default function Index() {
  const navigate = useNavigate();
  const { feiras } = useFeiras();
  const destaques = products.filter((p) => p.image).slice(0, 6);

  return (
    <div className="min-h-screen pb-44">
      {/* Cabeçalho */}
      <header className="gradient-green rounded-b-[2rem] px-4 pb-14 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={logo} alt="" className="h-10 w-10 rounded-xl bg-white/90 p-1" />
            <span className="text-xl font-extrabold text-primary-foreground">FeiraApp</span>
          </div>
          <button
            onClick={() => navigate("/feiras")}
            className="flex items-center gap-1 rounded-full bg-primary-foreground/20 px-3 py-1.5 text-sm font-semibold text-primary-foreground"
          >
            <MapPin size={14} />
            São Paulo, SP
          </button>
        </div>

        <p className="mt-5 text-base font-semibold text-primary-foreground/85">{greeting()}! 👋</p>
        <h1 className="font-display text-[1.7rem] font-extrabold leading-tight text-primary-foreground">
          O que vamos levar da feira hoje?
        </h1>
      </header>

      {/* Busca sobreposta ao cabeçalho */}
      <div className="-mt-7 px-4">
        <button
          onClick={() => navigate("/catalogo")}
          className="flex h-14 w-full items-center gap-3 rounded-2xl bg-card px-4 text-base text-muted-foreground shadow-card-hover ring-1 ring-border"
        >
          <Search size={22} className="text-primary" />
          Buscar frutas, verduras, queijos...
        </button>
      </div>

      {/* Catálogo */}
      <section className="mt-6 px-4">
        <SectionTitle
          action={
            <button onClick={() => navigate("/catalogo")} className={seeAll}>
              Ver tudo <ChevronRight size={16} />
            </button>
          }
        >
          Catálogo
        </SectionTitle>
        <div className="mt-3 grid grid-cols-3 gap-2.5">
          {categories.slice(0, 9).map((cat) => (
            <button
              key={cat.id}
              onClick={() => navigate(`/catalogo?cat=${cat.id}`)}
              className="flex flex-col items-center gap-1.5 rounded-2xl px-1 py-3 text-center ring-1 ring-black/5 transition active:scale-95"
              style={{ backgroundColor: `hsl(${cat.tint})` }}
            >
              <span className="text-3xl">{cat.emoji}</span>
              <span className="text-[0.8rem] font-bold leading-tight text-foreground">{cat.name}</span>
            </button>
          ))}
        </div>
        <button
          onClick={() => navigate("/catalogo")}
          className="mt-2.5 h-12 w-full rounded-2xl bg-muted text-base font-bold text-foreground"
        >
          Ver as {categories.length} categorias
        </button>
      </section>

      {/* Banner */}
      <div className="relative mx-4 mt-6 overflow-hidden rounded-3xl">
        <img src={heroFeira} alt="" className="h-40 w-full object-cover" width={1280} height={720} />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/40 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <h2 className="font-display text-2xl font-extrabold leading-tight text-primary-foreground">
            Fresquinho da
            <br />
            feira pra você
          </h2>
          <p className="mt-1 text-sm font-medium text-primary-foreground/85">Direto do produtor, sem sair de casa</p>
        </div>
      </div>

      {/* Feiras */}
      <section className="mt-6 px-4">
        <SectionTitle
          action={
            <button onClick={() => navigate("/feiras")} className={seeAll}>
              Ver no mapa <ChevronRight size={16} />
            </button>
          }
        >
          Feiras perto de você
        </SectionTitle>
        <div className="-mx-4 mt-3 flex gap-3 overflow-x-auto px-4 pb-2 scrollbar-none">
          {feiras.slice(0, 4).map((feira) => (
            <div key={feira.id} className="w-[280px] shrink-0">
              <FeiraCard feira={feira} />
            </div>
          ))}
        </div>

        <button
          onClick={() => navigate("/feiras?adicionar=1")}
          className="mt-3 flex w-full items-center gap-3 rounded-3xl bg-feira-orange-light p-4 text-left ring-1 ring-secondary/20"
        >
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground">
            <MapPinned size={24} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-base font-extrabold">Conhece uma feira que não está aqui?</span>
            <span className="block text-sm text-muted-foreground">Marque no mapa — clientes e feirantes podem</span>
          </span>
          <Plus size={22} className="shrink-0 text-secondary" />
        </button>
      </section>

      {/* Feirantes */}
      <section className="mt-6 px-4">
        <SectionTitle>Feirantes em destaque</SectionTitle>
        <div className="mt-3 flex flex-col gap-2.5">
          {feirantes.slice(0, 4).map((f, i) => (
            <motion.div
              key={f.id}
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              <FeiranteCard feirante={f} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Destaques */}
      <section className="mt-6 px-4">
        <SectionTitle
          action={
            <button onClick={() => navigate("/catalogo")} className={seeAll}>
              Catálogo <ChevronRight size={16} />
            </button>
          }
        >
          Mais pedidos da semana
        </SectionTitle>
        <div className="mt-3 grid grid-cols-2 gap-3">
          {destaques.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}
