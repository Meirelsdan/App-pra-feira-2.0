import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider } from "@/contexts/CartContext";
import { WalletProvider } from "@/contexts/WalletContext";
import { FeirasProvider } from "@/contexts/FeirasContext";
import { MapsProvider } from "@/components/map/FeiraMap";
import BottomNav from "@/components/BottomNav";
import SacolaFixa from "@/components/SacolaFixa";
import Index from "./pages/Index";
import CatalogPage from "./pages/CatalogPage";
import FeirasPage from "./pages/FeirasPage";
import FeiraDetailPage from "./pages/FeiraDetailPage";
import FeiranteDetailPage from "./pages/FeiranteDetailPage";
import CheckoutPage from "./pages/CheckoutPage";
import ProfilePage from "./pages/ProfilePage";
import WalletPage from "./pages/WalletPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <MapsProvider>
        <FeirasProvider>
          <WalletProvider>
            <CartProvider>
              <Sonner position="top-center" richColors closeButton toastOptions={{ className: "text-base" }} />
              <BrowserRouter>
                <div className="mx-auto min-h-screen max-w-lg bg-background shadow-[0_0_60px_-30px_hsl(var(--foreground)/0.25)]">
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/catalogo" element={<CatalogPage />} />
                    <Route path="/buscar" element={<CatalogPage />} />
                    <Route path="/feiras" element={<FeirasPage />} />
                    <Route path="/feira/:id" element={<FeiraDetailPage />} />
                    <Route path="/feirante/:id" element={<FeiranteDetailPage />} />
                    <Route path="/sacola" element={<CheckoutPage />} />
                    <Route path="/perfil" element={<ProfilePage />} />
                    <Route path="/perfil/carteira" element={<WalletPage />} />
                    <Route path="/carteira" element={<Navigate to="/perfil/carteira" replace />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                  <SacolaFixa />
                  <BottomNav />
                </div>
              </BrowserRouter>
            </CartProvider>
          </WalletProvider>
        </FeirasProvider>
      </MapsProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
