import { createContext, useContext, ReactNode } from "react";
import { newId, usePersistentState } from "@/lib/storage";

export type PaymentType = "pix" | "credito" | "debito" | "vale" | "dinheiro";

/**
 * Forma de pagamento salva na carteira.
 * Importante: nunca guardamos o número completo do cartão nem o CVV —
 * só bandeira e os 4 últimos dígitos, para o usuário reconhecer o cartão.
 * Em produção, o cartão deve ser tokenizado por um gateway (Mercado Pago, Pagar.me, Stripe...).
 */
export interface PaymentMethod {
  id: string;
  type: PaymentType;
  nickname: string;
  brand?: string;
  last4?: string;
  holder?: string;
  expiry?: string;
  changeFor?: number;
  isDefault: boolean;
}

export const paymentTypeInfo: Record<PaymentType, { label: string; emoji: string; description: string }> = {
  pix: { label: "Pix", emoji: "⚡", description: "Pague na hora com QR Code ou copia e cola" },
  credito: { label: "Cartão de crédito", emoji: "💳", description: "Visa, Mastercard, Elo, Amex, Hipercard" },
  debito: { label: "Cartão de débito", emoji: "🏧", description: "Débito na entrega ou pelo app" },
  vale: { label: "Vale-alimentação", emoji: "🍽️", description: "Alelo, Pluxee (Sodexo), Ticket, VR" },
  dinheiro: { label: "Dinheiro na entrega", emoji: "💵", description: "Pague ao receber, com troco se precisar" },
};

interface WalletContextType {
  methods: PaymentMethod[];
  defaultMethod?: PaymentMethod;
  addMethod: (m: Omit<PaymentMethod, "id" | "isDefault">, makeDefault?: boolean) => void;
  removeMethod: (id: string) => void;
  setDefault: (id: string) => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [methods, setMethods] = usePersistentState<PaymentMethod[]>("feiraapp:carteira", []);

  const addMethod: WalletContextType["addMethod"] = (m, makeDefault) => {
    setMethods((prev) => {
      const isDefault = makeDefault || prev.length === 0;
      const base = isDefault ? prev.map((p) => ({ ...p, isDefault: false })) : prev;
      return [...base, { ...m, id: newId(), isDefault }];
    });
  };

  const removeMethod = (id: string) => {
    setMethods((prev) => {
      const next = prev.filter((p) => p.id !== id);
      if (next.length > 0 && !next.some((p) => p.isDefault)) next[0] = { ...next[0], isDefault: true };
      return next;
    });
  };

  const setDefault = (id: string) => {
    setMethods((prev) => prev.map((p) => ({ ...p, isDefault: p.id === id })));
  };

  const defaultMethod = methods.find((m) => m.isDefault);

  return (
    <WalletContext.Provider value={{ methods, defaultMethod, addMethod, removeMethod, setDefault }}>
      {children}
    </WalletContext.Provider>
  );
}

export const useWallet = () => {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
};

export function describeMethod(m: PaymentMethod) {
  if (m.last4) return `${m.brand ?? paymentTypeInfo[m.type].label} •••• ${m.last4}`;
  if (m.type === "dinheiro" && m.changeFor) return `Troco para R$ ${m.changeFor.toFixed(2).replace(".", ",")}`;
  return paymentTypeInfo[m.type].description;
}

// --- utilidades de cartão -------------------------------------------------

export function detectCardBrand(digits: string): string | undefined {
  if (/^(4011|4312|4389|4514|4576|5041|5066|5067|509|6277|6362|6363|650|6516|6550)/.test(digits)) return "Elo";
  if (/^(606282|3841)/.test(digits)) return "Hipercard";
  if (/^3[47]/.test(digits)) return "Amex";
  if (/^4/.test(digits)) return "Visa";
  if (/^(5[1-5]|2[2-7])/.test(digits)) return "Mastercard";
  return undefined;
}

/** Algoritmo de Luhn: confere se o número do cartão é válido. */
export function isValidCardNumber(digits: string) {
  if (digits.length < 13 || digits.length > 19) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}

export function isValidExpiry(value: string) {
  const match = /^(\d{2})\/(\d{2})$/.exec(value);
  if (!match) return false;
  const month = Number(match[1]);
  const year = 2000 + Number(match[2]);
  if (month < 1 || month > 12) return false;
  const now = new Date();
  return year > now.getFullYear() || (year === now.getFullYear() && month >= now.getMonth() + 1);
}
