import { useEffect, useState } from "react";

/** useState que também salva no localStorage (sobrevive ao recarregar a página). */
export function usePersistentState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // armazenamento indisponível (aba anônima etc.) — segue só em memória
    }
  }, [key, value]);

  return [value, setValue] as const;
}

export const newId = () => Math.random().toString(36).slice(2, 10);
