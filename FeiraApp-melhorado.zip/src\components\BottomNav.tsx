import { Home, LayoutGrid, User, MapPinned } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

// A sacola não fica aqui: ela é a "Sacola Fixa", separada, logo acima deste menu.
const navItems = [
  { icon: Home, label: "Início", path: "/", match: (p: string) => p === "/" },
  {
    icon: LayoutGrid,
    label: "Catálogo",
    path: "/catalogo",
    match: (p: string) => p.startsWith("/catalogo") || p.startsWith("/buscar"),
  },
  {
    icon: MapPinned,
    label: "Feiras",
    path: "/feiras",
    match: (p: string) => p.startsWith("/feira"),
  },
  { icon: User, label: "Perfil", path: "/perfil", match: (p: string) => p.startsWith("/perfil") },
];

export default function BottomNav() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  return (
    <nav
      aria-label="Menu principal"
      className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md"
    >
      <div className="mx-auto grid max-w-lg grid-cols-4 gap-1 px-2 py-1.5">
        {navItems.map((item) => {
          const isActive = item.match(pathname);
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              aria-current={isActive ? "page" : undefined}
              className="relative flex flex-col items-center gap-0.5 rounded-2xl py-2 transition-colors"
            >
              {isActive && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute inset-0 rounded-2xl bg-accent"
                  transition={{ type: "spring", duration: 0.4 }}
                />
              )}
              <item.icon
                size={24}
                strokeWidth={isActive ? 2.6 : 2}
                className={`relative z-10 transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`}
              />
              <span
                className={`relative z-10 text-xs font-bold ${isActive ? "text-primary" : "text-muted-foreground"}`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
