import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Minus, Plus, Trash2 } from "lucide-react";
import { Product, getCategory } from "@/data/mockData";

/** Cabeçalho padrão das telas internas, com botão de voltar grande. */
export function PageHeader({
  title,
  subtitle,
  back = false,
  right,
}: {
  title: string;
  subtitle?: string;
  back?: boolean;
  right?: ReactNode;
}) {
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/90 px-4 pb-3 pt-4 backdrop-blur-md">
      <div className="flex items-center gap-3">
        {back && (
          <button
            onClick={() => navigate(-1)}
            aria-label="Voltar"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-card shadow-card ring-1 ring-border transition active:scale-95"
          >
            <ArrowLeft size={22} />
          </button>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-extrabold text-foreground">{title}</h1>
          {subtitle && <p className="truncate text-sm text-muted-foreground">{subtitle}</p>}
        </div>
        {right}
      </div>
    </header>
  );
}

/** Miniatura do produto: foto, se tiver, ou o emoji sobre a cor da categoria. */
export function ProductThumb({ product, className = "h-14 w-14 text-3xl" }: { product: Product; className?: string }) {
  const tint = getCategory(product.category)?.tint ?? "40 30% 94%";
  return (
    <div
      className={`flex shrink-0 items-center justify-center overflow-hidden rounded-2xl ${className}`}
      style={{ backgroundColor: `hsl(${tint})` }}
    >
      {product.image ? (
        <img src={product.image} alt="" className="h-full w-full object-cover" loading="lazy" />
      ) : (
        <span aria-hidden>{product.emoji}</span>
      )}
    </div>
  );
}

/** Botões − quantidade + com área de toque grande (pensado para quem tem dificuldade com telas pequenas). */
export function QuantityStepper({
  value,
  onChange,
  size = "md",
}: {
  value: number;
  onChange: (value: number) => void;
  size?: "sm" | "md";
}) {
  const btn = size === "sm" ? "h-9 w-9" : "h-11 w-11";
  return (
    <div className="flex items-center justify-between gap-1 rounded-2xl bg-accent p-1">
      <button
        onClick={() => onChange(value - 1)}
        aria-label={value === 1 ? "Remover da sacola" : "Diminuir quantidade"}
        className={`${btn} flex items-center justify-center rounded-xl bg-card text-foreground shadow-sm transition active:scale-90`}
      >
        {value === 1 ? <Trash2 size={18} className="text-destructive" /> : <Minus size={18} />}
      </button>
      <span className="min-w-[2ch] text-center text-lg font-extrabold text-accent-foreground" aria-live="polite">
        {value}
      </span>
      <button
        onClick={() => onChange(value + 1)}
        aria-label="Aumentar quantidade"
        className={`${btn} flex items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition active:scale-90`}
      >
        <Plus size={18} />
      </button>
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-2">
      <h2 className="text-lg font-extrabold text-foreground">{children}</h2>
      {action}
    </div>
  );
}
