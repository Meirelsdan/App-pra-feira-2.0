import { Star, Clock, MapPin, ChevronRight } from "lucide-react";
import { Feirante } from "@/data/mockData";
import { useNavigate } from "react-router-dom";

export default function FeiranteCard({ feirante }: { feirante: Feirante }) {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(`/feirante/${feirante.id}`)}
      className="flex w-full items-center gap-3 rounded-3xl bg-card p-3 text-left shadow-card ring-1 ring-border/60 transition-shadow hover:shadow-card-hover"
    >
      <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-accent text-3xl">
        {feirante.avatar}
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="truncate text-base font-bold text-foreground">{feirante.name}</h3>
        <p className="mt-0.5 line-clamp-1 text-sm text-muted-foreground">{feirante.description}</p>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-sm text-muted-foreground">
          <span className="flex items-center gap-0.5 font-bold text-secondary">
            <Star size={14} fill="currentColor" /> {feirante.rating.toString().replace(".", ",")}
          </span>
          <span className="flex items-center gap-0.5">
            <Clock size={14} /> {feirante.deliveryTime}
          </span>
          <span className="flex items-center gap-0.5">
            <MapPin size={14} /> {feirante.distance}
          </span>
        </div>
      </div>
      <ChevronRight size={20} className="shrink-0 text-muted-foreground" />
    </button>
  );
}
