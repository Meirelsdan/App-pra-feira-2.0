import { Plus, Leaf } from "lucide-react";
import { Product, formatPrice, getCategory } from "@/data/mockData";
import { useCart } from "@/contexts/CartContext";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { QuantityStepper } from "@/components/common";

export default function ProductCard({ product }: { product: Product }) {
  const { addItem, getQuantity, updateQuantity, setBagOpen } = useCart();
  const quantity = getQuantity(product.id);
  const tint = getCategory(product.category)?.tint ?? "40 30% 94%";

  const handleAdd = () => {
    addItem(product);
    toast.success(`${product.name} foi para a Sacola Fixa`, {
      action: { label: "Ver sacola", onClick: () => setBagOpen(true) },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group flex flex-col overflow-hidden rounded-3xl bg-card shadow-card ring-1 transition-shadow hover:shadow-card-hover ${
        quantity > 0 ? "ring-2 ring-primary/60" : "ring-border/60"
      }`}
    >
      <div className="relative aspect-[4/3] overflow-hidden" style={{ backgroundColor: `hsl(${tint})` }}>
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <span
            role="img"
            aria-label={product.name}
            className="absolute inset-0 flex items-center justify-center text-6xl drop-shadow-sm transition-transform duration-300 group-hover:scale-110"
          >
            {product.emoji}
          </span>
        )}
        {product.organic && (
          <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground shadow">
            <Leaf size={12} /> Orgânico
          </span>
        )}
        {quantity > 0 && (
          <span className="absolute right-2 top-2 rounded-full bg-secondary px-2 py-0.5 text-xs font-extrabold text-secondary-foreground shadow">
            {quantity} na sacola
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3">
        <h3 className="line-clamp-2 min-h-[2.6em] text-[0.95rem] font-bold leading-snug text-foreground">
          {product.name}
        </h3>
        <p className="mt-1">
          <span className="text-lg font-extrabold text-primary">{formatPrice(product.price)}</span>
          <span className="ml-1 text-sm text-muted-foreground">/{product.unit}</span>
        </p>
        <div className="mt-auto pt-2">
          {quantity === 0 ? (
            <button
              onClick={handleAdd}
              className="flex h-11 w-full items-center justify-center gap-1.5 rounded-2xl bg-primary text-sm font-extrabold text-primary-foreground shadow-md transition active:scale-95"
            >
              <Plus size={18} strokeWidth={3} /> Adicionar
            </button>
          ) : (
            <QuantityStepper value={quantity} onChange={(q) => updateQuantity(product.id, q)} />
          )}
        </div>
      </div>
    </motion.div>
  );
}
