import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Calendar, Clock, Navigation, Users, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { feirantes as allFeirantes } from "@/data/mockData";
import FeiranteCard from "@/components/FeiranteCard";
import FeiraMap, { directionsUrl, hasMapsKey } from "@/components/map/FeiraMap";
import { SectionTitle } from "@/components/common";
import { useFeiras } from "@/contexts/FeirasContext";

export default function FeiraDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { feiras, removeFeira, userLocation } = useFeiras();
  const feira = feiras.find((f) => f.id === id);

  if (!feira) return <div className="p-8 text-center text-lg text-muted-foreground">Feira não encontrada</div>;

  const feiraFeirantes = allFeirantes.filter((f) => feira.feirantes.includes(f.id));
  const hasPosition = feira.lat != null && feira.lng != null;

  return (
    <div className="min-h-screen pb-44">
      <div className="relative h-56 overflow-hidden">
        <img src={feira.image} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
        <button
          onClick={() => navigate(-1)}
          aria-label="Voltar"
          className="absolute left-3 top-3 flex h-11 w-11 items-center justify-center rounded-full bg-card/90 shadow backdrop-blur"
        >
          <ArrowLeft size={22} />
        </button>
        <div className="absolute bottom-4 left-4 right-4">
          {feira.source === "comunidade" && (
            <span className="mb-2 inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-0.5 text-xs font-bold text-secondary-foreground">
              <Users size={12} /> {feira.addedBy === "feirante" ? "Marcada por um feirante" : "Marcada por um cliente"}
            </span>
          )}
          <h1 className="font-display text-2xl font-extrabold leading-tight text-primary-foreground drop-shadow">
            {feira.name}
          </h1>
        </div>
      </div>

      <div className="px-4 pt-4">
        <div className="flex flex-col gap-2.5 rounded-3xl bg-card p-4 shadow-card ring-1 ring-border/60">
          <div className="flex items-start gap-2 text-base text-foreground">
            <MapPin size={18} className="mt-0.5 shrink-0 text-primary" />
            <span>
              {feira.address}
              {feira.distance && <span className="text-muted-foreground"> · {feira.distance}</span>}
            </span>
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-base text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar size={18} className="text-secondary" /> {feira.days}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock size={18} className="text-secondary" /> {feira.hours}
            </span>
          </div>
          {feira.bancaName && (
            <p className="rounded-2xl bg-feira-orange-light px-3 py-2 text-sm font-semibold">
              🧑‍🌾 Banca cadastrada: {feira.bancaName}
            </p>
          )}
        </div>

        {hasMapsKey && hasPosition && (
          <FeiraMap
            feiras={[feira]}
            selectedId={feira.id}
            userLocation={userLocation}
            center={{ lat: feira.lat!, lng: feira.lng! }}
            zoom={15}
            className="mt-4 h-52 rounded-3xl shadow-card ring-1 ring-border"
          />
        )}

        <a
          href={directionsUrl(feira)}
          target="_blank"
          rel="noreferrer"
          className="mt-3 flex h-14 items-center justify-center gap-2 rounded-2xl bg-primary text-base font-extrabold text-primary-foreground shadow-md"
        >
          <Navigation size={20} /> Como chegar (Google Maps)
        </a>

        <div className="mt-6">
          <SectionTitle>Feirantes nesta feira</SectionTitle>
        </div>
        <div className="mt-3 flex flex-col gap-3">
          {feiraFeirantes.map((f) => (
            <FeiranteCard key={f.id} feirante={f} />
          ))}
          {feiraFeirantes.length === 0 && (
            <p className="rounded-3xl bg-muted/60 p-5 text-center text-base text-muted-foreground">
              Ainda não há feirantes vendendo por aqui no app. 🌱
            </p>
          )}
        </div>

        {feira.source === "comunidade" && (
          <button
            onClick={() => {
              removeFeira(feira.id);
              toast.success("Ponto de feira removido");
              navigate("/feiras");
            }}
            className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-2xl text-sm font-bold text-destructive ring-1 ring-destructive/30"
          >
            <Trash2 size={16} /> Remover este ponto
          </button>
        )}
      </div>
    </div>
  );
}
