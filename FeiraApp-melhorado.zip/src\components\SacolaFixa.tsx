import { useLocation, useNavigate } from "react-router-dom";
import { ShoppingBasket, ChevronUp, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useCart, CartItem } from "@/contexts/CartContext";
import { feirantes, formatPrice } from "@/data/mockData";
import { ProductThumb, QuantityStepper } from "@/components/common";
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";

/** Agrupa os itens da sacola por feirante (cada um entrega separado). */
export function groupByFeirante(items: CartItem[]) {
  return feirantes
    .map((f) => ({ feirante: f, items: items.filter((i) => i.product.feiranteId === f.id) }))
    .filter((g) => g.items.length > 0);
}

/**
 * Sacola Fixa: barra sempre visível acima do menu, separada da navegação.
 * Mostra o que a pessoa já colocou e abre uma gaveta com a lista completa.
 */
export default function SacolaFixa() {
  const { items, totalItems, totalPrice, updateQuantity, clearCart, isBagOpen, setBagOpen } = useCart();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  // na tela de fechar pedido a sacola já aparece inteira
  if (pathname === "/sacola") return null;

  const groups = groupByFeirante(items);
  const empty = items.length === 0;

  return (
    <>
      <div className="pointer-events-none fixed inset-x-0 bottom-[calc(4.6rem_+_env(safe-area-inset-bottom))] z-40">
        <div className="pointer-events-auto mx-auto max-w-lg px-3">
          <button
            onClick={() => setBagOpen(true)}
            aria-label={`Abrir Sacola Fixa: ${totalItems} itens`}
            className={`flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left shadow-bag transition active:scale-[0.98] ${
              empty ? "bg-card ring-1 ring-border" : "gradient-orange text-secondary-foreground"
            }`}
          >
            <span
              className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                empty ? "bg-accent text-primary" : "bg-white/25"
              }`}
            >
              <ShoppingBasket size={24} />
              {!empty && (
                <motion.span
                  key={totalItems}
                  initial={{ scale: 0.4 }}
                  animate={{ scale: 1 }}
                  className="absolute -right-1.5 -top-1.5 flex h-6 min-w-[24px] items-center justify-center rounded-full bg-white px-1 text-xs font-black text-secondary"
                >
                  {totalItems}
                </motion.span>
              )}
            </span>

            <span className="min-w-0 flex-1">
              <span className={`block text-xs font-bold uppercase tracking-wide ${empty ? "text-muted-foreground" : "opacity-90"}`}>
                Sacola Fixa
              </span>
              {empty ? (
                <span className="block truncate text-sm font-semibold text-foreground">Vazia — toque em “Adicionar”</span>
              ) : (
                <span className="flex items-center gap-1.5">
                  <span className="text-lg font-black leading-tight">{formatPrice(totalPrice)}</span>
                  <span className="truncate text-sm" aria-hidden>
                    {items
                      .slice(0, 5)
                      .map((i) => i.product.emoji)
                      .join(" ")}
                  </span>
                </span>
              )}
            </span>

            <span
              className={`flex shrink-0 items-center gap-1 rounded-xl px-3 py-2 text-sm font-extrabold ${
                empty ? "bg-muted text-muted-foreground" : "bg-white text-secondary"
              }`}
            >
              Ver <ChevronUp size={16} />
            </span>
          </button>
        </div>
      </div>

      <Drawer open={isBagOpen} onOpenChange={setBagOpen}>
        <DrawerContent className="mx-auto max-h-[92vh] max-w-lg rounded-t-3xl">
          <DrawerHeader className="text-left">
            <DrawerTitle className="flex items-center gap-2 text-2xl font-extrabold">
              <ShoppingBasket className="text-secondary" /> Sacola Fixa
            </DrawerTitle>
            <DrawerDescription className="text-base">
              {empty
                ? "Sua sacola está vazia."
                : `${totalItems} ${totalItems === 1 ? "item" : "itens"} de ${groups.length} ${
                    groups.length === 1 ? "feirante" : "feirantes"
                  }`}
            </DrawerDescription>
          </DrawerHeader>

          <div className="flex-1 overflow-y-auto px-4">
            {empty && (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <span className="text-6xl">🧺</span>
                <p className="text-base text-muted-foreground">
                  Escolha produtos no catálogo e toque em <b>Adicionar</b>. Eles aparecem aqui.
                </p>
              </div>
            )}

            {groups.map(({ feirante, items: groupItems }) => (
              <section key={feirante.id} className="mb-4">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-extrabold text-muted-foreground">
                  <span className="text-lg">{feirante.avatar}</span> {feirante.name}
                </h3>
                <div className="flex flex-col gap-2">
                  <AnimatePresence initial={false}>
                    {groupItems.map(({ product, quantity }) => (
                      <motion.div
                        key={product.id}
                        layout
                        exit={{ opacity: 0, x: -80 }}
                        className="flex items-center gap-3 rounded-2xl bg-card p-2.5 shadow-card ring-1 ring-border/60"
                      >
                        <ProductThumb product={product} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-base font-bold text-foreground">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {formatPrice(product.price)}/{product.unit}
                          </p>
                          <p className="text-base font-extrabold text-primary">
                            {formatPrice(product.price * quantity)}
                          </p>
                        </div>
                        <div className="w-[8.5rem] shrink-0">
                          <QuantityStepper
                            size="sm"
                            value={quantity}
                            onChange={(q) => updateQuantity(product.id, q)}
                          />
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </section>
            ))}
          </div>

          <DrawerFooter className="border-t border-border bg-card/80">
            {!empty && (
              <div className="flex items-center justify-between">
                <span className="text-base font-semibold text-muted-foreground">Subtotal</span>
                <span className="text-2xl font-black text-foreground">{formatPrice(totalPrice)}</span>
              </div>
            )}
            {!empty && (
              <button
                onClick={() => {
                  setBagOpen(false);
                  navigate("/sacola");
                }}
                className="gradient-green h-14 rounded-2xl text-lg font-extrabold text-primary-foreground shadow-md transition active:scale-[0.98]"
              >
                Fechar pedido
              </button>
            )}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setBagOpen(false);
                  if (empty) navigate("/catalogo");
                }}
                className="h-12 flex-1 rounded-2xl bg-muted text-base font-bold text-foreground"
              >
                {empty ? "Ir ao catálogo" : "Continuar comprando"}
              </button>
              {!empty && (
                <button
                  onClick={clearCart}
                  aria-label="Esvaziar sacola"
                  className="flex h-12 items-center gap-1 rounded-2xl px-4 text-sm font-bold text-destructive ring-1 ring-destructive/30"
                >
                  <Trash2 size={16} /> Esvaziar
                </button>
              )}
            </div>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    </>
  );
}
